# Grammar QG P20a Answer-Acceptance and Audit-Evidence Hotfix Contract

Status: proposed patch-ready contract  
Source authority: uploaded lean ZIP `ks2-mastery-lean-05051901.zip`  
Subject scope: Grammar only  
Out of scope: Punctuation subject, subject reward/mastery, Hero Mode, monster/Star projection, live production rollout  
Base release under review: `grammar-qg-p20-2026-05-05`

## 1. Problem statement

The P20 Grammar question-generator gates pass on the uploaded ZIP snapshot, but adversarial validation found learner-facing answer-acceptance glitches that can still damage trust.

The affected cases are deterministic closed Grammar questions, not genuinely open writing. The current implementation can ask for a small answer unit, but only accept the generated full-sentence answer. It can also reject common spelling variants for grammar labels, reject harmless final full-stop differences in some punctuation-pattern repairs, and silently truncate P20 recovered-case evidence.

These are not pool-size problems. They are correctness and trust problems.

## 2. Bugs found on the uploaded ZIP snapshot

### 2.1 Modal-verb blank tasks reject the fill-only answer

Example template:

`qg_p18_p18_modal_verbs_precision_repair_or_rewrite`

Prompt shape:

`Complete the sentence with the best modal verb for strong advice: You ___ wear a helmet on this trail.`

The generated golden answer is the full sentence:

`You should wear a helmet on this trail.`

A learner answer of `should` is logically correct, but the original snapshot rejects it.

A prohibition example also rejects `must not`, even though the blank is the learner-facing answer unit.

### 2.2 Tense/aspect repair tasks reject the corrected verb phrase

Example template:

`qg_p18_p15_tense_aspect_tense_editing`

Prompt shape:

`Fix the verb form so it matches "present perfect": I finish my homework.`

The generated golden answer is the full sentence:

`I have finished my homework.`

A learner answer of `have finished` is logically correct, but the original snapshot rejects it.

### 2.3 Boundary punctuation labels reject common semicolon variants

A deterministic label answer of `semicolon` rejects `semi-colon` and `semi colon`.

These are common learner/teacher spellings and should be accepted as equivalent grammar labels.

### 2.4 Some recovered punctuation-pattern repairs are over-strict about incidental terminal full stops

Example template:

`qg_p18_p16_parenthesis_commas_add_parenthesis_commas`

Prompt shape:

`Add commas for parenthesis if needed: Luca who was first in line opened the door.`

The target skill is the parenthesis commas. The original snapshot rejects:

`Luca, who was first in line, opened the door`

because the final full stop is missing, even though the target commas are correct.

This tolerance must be narrow. It must not make direct-speech punctuation, ending-punctuation classification, or missing target commas pass.

### 2.5 The normaliser can strip grammar-critical terminal apostrophes

The original `stripWrappingQuotes` removes leading/trailing quote-like characters independently. That means a future/current normalised-text answer expecting `dogs'` can wrongly accept `dogs`.

This is a latent false-positive risk for possessive-apostrophe Grammar content.

### 2.6 P20 audit evidence silently truncates recovered closed auto-mark cases

The P20 quality-hardening audit summary reports:

`p20ClosedAutoMarkCaseCount = 690`

but the emitted `p20ClosedAutoMark` evidence list only contains 200 entries. This makes review evidence incomplete while still presenting a full denominator in the summary.

## 3. Required implementation

### 3.1 Preserve grammar-critical apostrophes

Replace independent leading/trailing quote stripping with paired-wrapper stripping only.

Accepted wrappers:

- `"answer"`
- `'answer'`
- `` `answer` ``

Do not strip an unmatched terminal apostrophe from an answer such as `dogs'`.

### 3.2 Add safe grammar-label aliases

Canonicalise these label variants before comparing normalised text:

- `semi-colon` -> `semicolon`
- `semi colon` -> `semicolon`

The aliasing must remain narrow and must not make unrelated punctuation labels equivalent.

### 3.3 Add prompt-aware accepted variants for deterministic closed normalised-text recovered items

For P20 recovered closed auto-mark families using `normalisedText`, derive additional accepted answers from the prompt/golden pair when the prompt clearly asks for a smaller answer unit.

Required derivations:

- Blank-fill prompts with `___` must accept the filled text as well as the full generated sentence.
- Verb-form repair prompts starting with `Fix the verb form...` must accept the corrected verb phrase as well as the full generated sentence.

These variants must be generated from the existing prompt and accepted full answer, not hard-coded to one seed only.

### 3.4 Add narrow optional terminal-full-stop tolerance for non-terminal punctuation-pattern repairs

For recovered `punctuationPattern` Grammar items whose prompt asks for commas, parenthesis commas, or hyphens, allow an incidental final full-stop mismatch.

Keep strictness for:

- ending punctuation tasks;
- direct-speech punctuation tasks;
- speech punctuation tasks;
- missing target commas;
- missing target hyphens;
- internal punctuation differences.

### 3.5 Emit complete P20 recovered-case audit evidence

The P20 audit must emit all recovered closed auto-mark cases that it counts. For the current P20 denominator this means 690 entries, not a hidden 200-entry sample.

## 4. Required tests

The patch must add automated tests for all bugs above.

Minimum direct cases:

- `should` is accepted for the modal blank while `could` remains rejected.
- `must not` is accepted for the prohibition modal blank.
- `have finished` is accepted for the tense/aspect repair while `finish` remains rejected.
- `semi-colon` and `semi colon` are accepted for a `semicolon` grammar-label answer.
- Missing incidental final full stop is accepted in the parenthesis-comma repair.
- Missing target commas remain rejected in the parenthesis-comma repair.
- `dogs` must not be accepted when the golden normalised answer is `dogs'`.
- Quoted `"dogs'"` remains accepted when the golden answer is `dogs'`.
- P20 quality-hardening audit emits the full recovered-case evidence list.

## 5. Acceptance commands

Run from a fresh extraction of the uploaded ZIP after applying the patch:

```bash
patch --dry-run -p1 < patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch
patch -p1 < patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch

node --test \
  tests/grammar-answer-spec.test.js \
  tests/grammar-qg-p20-answer-acceptance.test.js

node --test \
  tests/grammar-answer-spec.test.js \
  tests/grammar-answer-spec-audit.test.js \
  tests/grammar-question-generator-audit.test.js \
  tests/grammar-qg-p20-answer-acceptance.test.js \
  tests/grammar-qg-p20-quality-hardening.test.js

node scripts/audit-grammar-content-quality.mjs --seeds=1..30 --json
node scripts/audit-grammar-open-response-fairness.mjs --seeds=1..30 --out=/tmp/grammar-open-response-fairness.json
node scripts/audit-grammar-qg-p20-quality-hardening.mjs --seeds=1..30 --smart-seeds=1..6 --out=/tmp/grammar-qg-p20-quality-hardening.json
```

Expected results:

- no test failures;
- content quality: `hardFailCount = 0`, `advisoryCount = 0`;
- open-response fairness: `passed = true`, `findingCount = 0`;
- P20 quality hardening: `passed = true`;
- P20 recovered auto-mark summary: `p20ClosedAutoMarkCaseCount = 690`;
- emitted `p20ClosedAutoMark` list length: `690`.

## 6. Release/version handling

This patch intentionally does not change `GRAMMAR_CONTENT_RELEASE_ID`. It is a P20a hotfix against the P20 snapshot, focused on answer acceptance and audit evidence. If the team requires release-id semantics, apply the patch first, regenerate release evidence, then bump the release id in a follow-up release contract.

## 7. Non-goals

This contract does not expand the 15k pool, change manual-review-only policy for genuinely open writing, alter subject mastery, alter Stars/rewards, or touch the Punctuation subject.
