# Validation Summary — Grammar QG P20a Hotfix

## Source boundary

Primary source: uploaded lean ZIP `ks2-mastery-lean-05051901.zip`.

Source ZIP SHA-256:

`80e8e6f107f64a6a8ce5877fc7ba7075633517889cd2d26f953576c465ee5610`

The ZIP is a lean review bundle with intentional asset placeholders. It is enough for Grammar source/tests/audits, but it does not prove live production.

## Initial ZIP validation

The uploaded ZIP integrity check passed.

Environment:

- `.nvmrc`: `22`
- local Node: `v22.16.0`
- local npm: `10.9.2`

Original bundled Grammar P20 verifier:

```bash
npm run verify:grammar-qg-p20
```

Result: passed locally on the uploaded ZIP snapshot.

Original P20 audit summary:

- release: `grammar-qg-p20-2026-05-05`
- template count: `510`
- manual-review-only templates: `157`
- recovered closed auto-mark templates: `23`
- recovered closed auto-mark generated cases: `690`
- answer-acceptance failures reported by bundled audit: `0`
- fairness findings: `0`
- template-quality findings: `0`

## Bugs/glitches found beyond the bundled gates

Adversarial probe on the original ZIP returned:

```text
modal blank should accept modal only: false
modal prohibition should accept must not: false
tense fix should accept verb phrase only: false
semicolon spelling alias semi-colon: false
parenthesis comma task should allow incidental final full stop omission: false
terminal possessive apostrophe should remain required: true
```

Interpretation:

1. Modal blank-fill Grammar questions rejected logically correct fill-only answers such as `should` and `must not`.
2. Tense/aspect repair questions rejected logically correct corrected verb phrases such as `have finished`.
3. Boundary punctuation label answers rejected common variants `semi-colon` and `semi colon`.
4. Some comma/parenthesis punctuation-pattern repairs were too strict about an incidental final full stop.
5. The normaliser could wrongly accept `dogs` for a golden answer of `dogs'`, because it stripped a grammar-critical terminal apostrophe as if it were a wrapper quote.
6. The P20 quality-hardening audit counted 690 recovered closed auto-mark cases but emitted only 200 evidence rows.

## Patch provided

Patch file:

`patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch`

Changed files:

- `worker/src/subjects/grammar/answer-spec.js`
- `worker/src/subjects/grammar/content.js`
- `scripts/audit-grammar-qg-p20-quality-hardening.mjs`
- `tests/grammar-answer-spec.test.js`
- `tests/grammar-qg-p20-answer-acceptance.test.js`

Patch behaviours:

- preserves grammar-critical unmatched apostrophes;
- accepts paired quote wrappers safely;
- accepts `semi-colon` and `semi colon` as aliases for `semicolon`;
- derives accepted blank-fill variants from deterministic P20 recovered prompts;
- derives accepted verb-form repair variants from deterministic P20 recovered prompts;
- allows optional terminal full-stop tolerance only for safe recovered punctuation-pattern repair prompts;
- keeps missing target punctuation rejected;
- emits the full P20 recovered closed auto-mark evidence list instead of silently truncating it.

## Patch dry-run and fresh-apply validation

Patch dry-run from a fresh extraction:

```bash
patch --dry-run -p1 < patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch
```

Result: passed.

Fresh patch apply from a fresh extraction:

```bash
patch -p1 < patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch
```

Result: applied cleanly.

Fresh patched targeted tests:

```bash
node --test tests/grammar-answer-spec.test.js tests/grammar-qg-p20-answer-acceptance.test.js
```

Result: 28/28 passed.

## Patched validation results

Patched adversarial probe:

```text
modal blank should accept modal only: true
modal prohibition should accept must not: true
tense fix should accept verb phrase only: true
semicolon spelling alias semi-colon: true
parenthesis comma task should allow incidental final full stop omission: true
terminal possessive apostrophe should remain required: false
```

The last line is expected: it means `dogs` is no longer accepted for golden `dogs'`.

Patched final test set:

```bash
node --test \
  tests/grammar-answer-spec.test.js \
  tests/grammar-answer-spec-audit.test.js \
  tests/grammar-question-generator-audit.test.js \
  tests/grammar-qg-p20-answer-acceptance.test.js \
  tests/grammar-qg-p20-quality-hardening.test.js
```

Result: 48/48 passed.

Patched content-quality audit:

```bash
node scripts/audit-grammar-content-quality.mjs --seeds=1..30 --json
```

Result:

- total templates checked: `15300`
- hard failures: `0`
- advisories: `0`

Patched open-response fairness audit:

```bash
node scripts/audit-grammar-open-response-fairness.mjs --seeds=1..30 --out=/tmp/grammar-open-response-fairness.json
```

Result:

- passed: `true`
- finding count: `0`

Patched P20 quality-hardening audit:

```bash
node scripts/audit-grammar-qg-p20-quality-hardening.mjs --seeds=1..30 --smart-seeds=1..6 --out=/tmp/grammar-qg-p20-quality-hardening.json
```

Result:

- passed: `true`
- template count: `510`
- seeds checked: `30`
- recovered closed auto-mark templates: `23`
- recovered closed auto-mark cases: `690`
- answer-acceptance failures: `0`
- fairness findings: `0`
- template-quality findings: `0`
- unsafe auto-marked open prompts: `0`
- smart-practice failures: `0`
- smart-practice advisories: `0`
- emitted `p20ClosedAutoMark` evidence rows: `690`

Original evidence truncation comparison:

- original audit summary case count: `690`
- original emitted evidence rows: `200`
- patched audit summary case count: `690`
- patched emitted evidence rows: `690`

## Limitations

This is ZIP-local validation only. It does not certify live production, Cloudflare/D1 behaviour, or deployed release evidence.

The full patched chained command `npm run verify:grammar-qg-p20` was not used as final evidence because local chained runs exceeded the execution window after the earlier components had passed. Instead, the same relevant component tests/audits were run directly and are included in this package.

The patch intentionally does not change `GRAMMAR_CONTENT_RELEASE_ID`; treat it as a P20a hotfix unless the team decides to bump and regenerate release evidence.
