# Grammar QG P20a Validation and Hotfix Package

This package validates the uploaded lean ZIP `ks2-mastery-lean-05051901.zip` and provides a Grammar-only hotfix patch for answer-acceptance and audit-evidence issues found during adversarial probing.

## Contents

- `contract/grammar-qg-p20a-answer-acceptance-and-audit-evidence-contract.md`
- `patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch`
- `validation-summary.md`
- `validation/` logs, JSON outputs, source ZIP identity, and bug probes

## Apply

From a fresh extraction of the uploaded ZIP/repo root:

```bash
patch --dry-run -p1 < patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch
patch -p1 < patches/001-grammar-qg-p20a-answer-acceptance-and-evidence.patch
```

## Recommended post-patch checks

```bash
node --test \
  tests/grammar-answer-spec.test.js \
  tests/grammar-answer-spec-audit.test.js \
  tests/grammar-question-generator-audit.test.js \
  tests/grammar-qg-p20-answer-acceptance.test.js \
  tests/grammar-qg-p20-quality-hardening.test.js

node scripts/audit-grammar-content-quality.mjs --seeds=1..30 --json
node scripts/audit-grammar-open-response-fairness.mjs --seeds=1..30 --out=/tmp/grammar-open-response-fairness.json
node scripts/audit-grammar-qg-p20-quality-hardening.mjs --seeds=1..30 --smart-seeds=1..6 --out=/tmp/grammar-qg-p20-quality-hardening.json
```

The patch is scoped to Grammar QG P20. It does not touch the Punctuation subject.
