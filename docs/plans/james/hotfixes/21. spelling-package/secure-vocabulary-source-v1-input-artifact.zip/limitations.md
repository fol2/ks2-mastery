# Limitations

- This package supplies the missing source list but does not claim that the new secure-extension candidates are adult-approved.
- The owner/adult reviewer must approve or reject the exact JSONL hash before the local agent promotes candidates into a secure/live release.
- The package does not include generated spelling sentences, audio, release files, migration output, reviewer-pack output, CI output, or production evidence.
- Some words are deliberately marked with `adult_review_context_sensitivity` advisories; those should be reviewed, removed, or downgraded before secure promotion.
- The package keeps existing current words and new candidate words separate. The local agent must preserve that separation.
