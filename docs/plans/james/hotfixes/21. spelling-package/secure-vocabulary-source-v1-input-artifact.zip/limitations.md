# Limitations

- This package supplies the missing source list and records James's approval for import/reviewer-pack generation against the exact JSONL hash.
- This approval is not approval for secure/live promotion. The local agent must not promote candidates into a secure/live release without an explicit `APPROVED_FOR_SECURE_EXTENSION_IMPORT` decision plus import, release, CI, and production evidence.
- The package does not include generated spelling sentences, audio, release files, migration output, reviewer-pack output, CI output, or production evidence.
- Some words are deliberately marked with `adult_review_context_sensitivity` advisories; those should be reviewed, removed, or downgraded before secure promotion.
- The package keeps existing current words and new candidate words separate. The local agent must preserve that separation.
