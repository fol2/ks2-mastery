# Local-agent stop-loop contract: Spelling secure vocabulary source v1

## Purpose

This package supplies the missing finite input artefact for the KS2 Mastery Spelling secure-vocabulary expansion. The local agent must stop searching B3w worktrees for a source list and use this package as the source boundary.

## Source authority

Authoritative source list for this task:

- `source/secure-vocabulary-source-v1.jsonl`
- SHA-256: `ae39bfc5091525d602f158c18d254b57c498683f9ae81da4d2733f225862a42c`
- Records: 1463
- Unique words: 1463
- Existing current snapshot records: 246
- New secure-extension candidate records: 1217

The uploaded repo/ZIP/GitHub state does not override this source list unless the owner explicitly supplies a replacement manifest and hash.

## Status words the agent must use

- `SOURCE LIST SUPPLIED — ADULT APPROVAL PENDING` if `approval/owner-approval-record.json` is still pending.
- `SOURCE LIST APPROVED — IMPORT/REVIEWER PACK REQUIRED` if the owner approval file is completed and hash-matched.
- `IMPLEMENTED + LOCAL VERIFIED — PRODUCTION NOT PROVEN` if the source is imported locally and validated but not live-verified.
- `DONE — LIVE VERIFIED` only if deployed and verified on `https://ks2.eugnel.uk` after hard refresh.

Do not say `missing secure vocabulary source list` after this package is in scope. If approval is absent, the blocker is approval, not source-list discovery.

## No-go areas

Do not touch reward, mastery, Stars, Hero Mode, monsters, subject progression, production config, or unrelated Grammar/Punctuation code while consuming this source artefact.

## Exact implementation tasks

1. Verify package hashes against `manifest.json`.
2. Verify `source/secure-vocabulary-source-v1.jsonl` schema and no duplicate `normalisedWord` values.
3. Read `approval/owner-approval-record.json`.
4. If approval is pending, generate an adult reviewer pack from the exact list and stop with the finite status `SOURCE LIST SUPPLIED — ADULT APPROVAL PENDING`.
5. If approval is present and hash-matched, import only the approved records according to the decision value.
6. Keep current statutory/current-extra words distinct from `secure_extension_candidate` records.
7. Generate import proof, reviewer-pack proof, validation proof, and source-hash proof.
8. Do not promote candidates into live secure/core coverage unless adult approval says `APPROVED_FOR_SECURE_EXTENSION_IMPORT` and all local/CI validations pass.

## Acceptance criteria

- The agent never searches indefinitely for another source list.
- The exact JSONL hash is printed in the final evidence.
- Current statutory/core vocabulary, current extra vocabulary, and secure-extension candidates are reported separately.
- Candidate words are not mislabelled as DfE statutory words.
- Adult approval is tied to the exact JSONL hash.
- Import/reviewer-pack outputs carry the same source hash.
- Production is not claimed unless `https://ks2.eugnel.uk` is live-checked after hard refresh.

## Required final evidence

- Source artefact path and SHA-256.
- Approval decision and matching source hash, or explicit pending approval status.
- Import command/output.
- Reviewer-pack command/output.
- Validation commands/output.
- Any rejected/advisory words and resolution.
- Production status using the project wording rules.
