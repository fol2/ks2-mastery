# KS2 Spelling secure-vocabulary source v1 input artefact

This package is designed to stop the local-agent loop caused by a missing adult-reviewed secure vocabulary source.

It supplies a finite pinned source list. It does **not** fabricate adult approval.

Start here:

1. `manifest.json`
2. `source/secure-vocabulary-source-v1.jsonl`
3. `approval/owner-approval-record.json`
4. `contract/LOCAL_AGENT_STOP_LOOP_CONTRACT.md`

Core facts:

- Total records: 1463
- Unique words: 1463
- Current published spelling snapshot records included: 246
- New secure-extension candidate records: 1217
- Source JSONL SHA-256: `ae39bfc5091525d602f158c18d254b57c498683f9ae81da4d2733f225862a42c`

This source must be treated as source-list evidence only. It is not production evidence.
