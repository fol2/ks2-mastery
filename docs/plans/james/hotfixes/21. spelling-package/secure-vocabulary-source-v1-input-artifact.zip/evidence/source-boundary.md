# Source boundary

This package is an input artefact, not a code patch and not production proof.

Evidence layers:

- Existing current spelling words came from the uploaded ZIP snapshot `ks2-mastery-lean-05161145.zip`, release `spelling-r5` inside `content/spelling.seed.json`.
- New secure-extension candidate words were generated as an explicit candidate source list for owner/adult review.
- GitHub is not authoritative for this source artefact unless the local agent separately fetches and compares a named ref.
- Production is not proven by this package.

The field-guide rule still applies: ZIP evidence, GitHub evidence, local-run evidence, and production evidence are separate layers.
