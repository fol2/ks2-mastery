#!/usr/bin/env node
/*
 * Punctuation QG P10 certification evidence validator prototype.
 *
 * Purpose:
 *   Fail closed on the exact class of evidence drift found in P9: a manifest that
 *   names a commit SHA but cannot prove that the commit contains the verified
 *   Punctuation QG files.
 *
 * Intended home in the repository:
 *   scripts/validate-punctuation-qg-certification-evidence.mjs
 *
 * Usage:
 *   node scripts/validate-punctuation-qg-certification-evidence.mjs \
 *     reports/punctuation/punctuation-qg-p10-certification-manifest.json \
 *     --root .
 *
 * Notes:
 *   This validator is strict by default. It expects to run in a repository clone
 *   with .git available. A lean ZIP without .git can validate shape, but it
 *   cannot certify Git provenance; that should remain a blocker, not a silent pass.
 */

import { existsSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve, join } from 'node:path';

const args = process.argv.slice(2);
const manifestPath = args.find((arg) => !arg.startsWith('--'));
const rootFlagIndex = args.indexOf('--root');
const root = rootFlagIndex >= 0 ? resolve(args[rootFlagIndex + 1] || '.') : process.cwd();
const allowZipOnly = args.includes('--allow-zip-only-shape-check');

if (!manifestPath) {
  console.error('Usage: node validate-punctuation-qg-certification-evidence.mjs <manifest.json> [--root .] [--allow-zip-only-shape-check]');
  process.exit(2);
}

const errors = [];
const warnings = [];

function fail(message) {
  errors.push(message);
}

function warn(message) {
  warnings.push(message);
}

function readJson(path) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'));
  } catch (error) {
    fail(`Cannot read JSON manifest: ${error.message}`);
    return null;
  }
}

function isPlainObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function isPlaceholder(value) {
  if (value == null) return true;
  if (typeof value !== 'string') return false;
  const normalised = value.trim().toLowerCase();
  return normalised === ''
    || normalised.includes('pending')
    || normalised.includes('todo')
    || normalised.includes('tbd')
    || normalised.includes('unknown')
    || normalised.includes('<')
    || normalised.includes('>');
}

function assertNoPlaceholder(label, value) {
  if (isPlaceholder(value)) fail(`${label} is missing or placeholder: ${JSON.stringify(value)}`);
}

function assertString(label, value) {
  if (typeof value !== 'string') fail(`${label} must be a string`);
}

function assertOneOf(label, value, allowed) {
  if (!allowed.includes(value)) fail(`${label} must be one of ${allowed.join(', ')}; got ${JSON.stringify(value)}`);
}

function assertRegex(label, value, regex, hint) {
  if (typeof value !== 'string' || !regex.test(value)) fail(`${label} has invalid format${hint ? ` (${hint})` : ''}: ${JSON.stringify(value)}`);
}

function sha256Buffer(buffer) {
  return createHash('sha256').update(buffer).digest('hex');
}

function repoHasGit(rootDir) {
  return existsSync(join(rootDir, '.git'));
}

function git(args, options = {}) {
  return execFileSync('git', ['-C', root, ...args], { encoding: options.encoding || 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
}

function validateVerifiedPathAtCommit(commitSha, entry) {
  const path = entry.path;
  let blobSha;
  try {
    blobSha = git(['rev-parse', `${commitSha}:${path}`]);
  } catch {
    fail(`Git commit ${commitSha} does not contain verified path: ${path}`);
    return;
  }

  if (entry.gitBlobSha && blobSha !== entry.gitBlobSha) {
    fail(`gitBlobSha mismatch for ${path}: manifest=${entry.gitBlobSha}, git=${blobSha}`);
  }

  let content;
  try {
    content = execFileSync('git', ['-C', root, 'cat-file', '-p', `${commitSha}:${path}`]);
  } catch {
    fail(`Cannot read ${path} from Git commit ${commitSha}`);
    return;
  }

  const actualSha256 = sha256Buffer(content);
  if (entry.sha256 && actualSha256 !== entry.sha256) {
    fail(`sha256 mismatch for ${path}: manifest=${entry.sha256}, gitContent=${actualSha256}`);
  }

  if (typeof entry.bytes === 'number' && content.length !== entry.bytes) {
    fail(`byte length mismatch for ${path}: manifest=${entry.bytes}, gitContent=${content.length}`);
  }
}

function validateLocalPath(entry) {
  const path = entry.path;
  const localPath = resolve(root, path);
  if (!existsSync(localPath)) {
    warn(`Local path not present in this checkout/ZIP: ${path}`);
    return;
  }
  const content = readFileSync(localPath);
  const actualSha256 = sha256Buffer(content);
  if (entry.sha256 && actualSha256 !== entry.sha256) {
    fail(`local sha256 mismatch for ${path}: manifest=${entry.sha256}, local=${actualSha256}`);
  }
  if (typeof entry.bytes === 'number' && content.length !== entry.bytes) {
    fail(`local byte length mismatch for ${path}: manifest=${entry.bytes}, local=${content.length}`);
  }
}

const manifest = readJson(resolve(manifestPath));

if (manifest) {
  if (manifest.schemaVersion !== 1) fail(`schemaVersion must be 1; got ${JSON.stringify(manifest.schemaVersion)}`);
  if (manifest.subject !== 'punctuation') fail(`subject must be "punctuation"; got ${JSON.stringify(manifest.subject)}`);
  if (manifest.phase !== 'punctuation-qg-p10') fail(`phase must be "punctuation-qg-p10"; got ${JSON.stringify(manifest.phase)}`);

  assertOneOf('certificationStatus', manifest.certificationStatus, [
    'BLOCKED',
    'CERTIFIED_PRE_DEPLOY',
    'CERTIFIED_POST_DEPLOY',
    'DEPTH6_BLOCKED_BUT_DEPTH4_CERTIFIED',
  ]);
  assertNoPlaceholder('releaseId', manifest.releaseId);
  assertNoPlaceholder('createdAt', manifest.createdAt);

  const source = manifest.source || {};
  const zip = source.zip || {};
  const gitSource = source.git || {};

  assertNoPlaceholder('source.layer', source.layer);
  assertNoPlaceholder('source.zip.sha256', zip.sha256);
  assertRegex('source.zip.sha256', zip.sha256, /^[a-f0-9]{64}$/i, '64 hex chars');

  assertNoPlaceholder('source.git.repository', gitSource.repository);
  assertNoPlaceholder('source.git.ref', gitSource.ref);
  assertRegex('source.git.commitSha', gitSource.commitSha, /^[a-f0-9]{40}$/i, '40 hex chars');
  if (gitSource.commitContainsAllVerifiedPaths !== true) {
    fail('source.git.commitContainsAllVerifiedPaths must be true after verification');
  }

  const pool = manifest.runtimePool || {};
  if (pool.productionDepth !== 4) fail(`runtimePool.productionDepth must remain 4 for P10 depth-4 release; got ${JSON.stringify(pool.productionDepth)}`);
  if (pool.fixedItems !== 92) fail(`runtimePool.fixedItems must be 92; got ${JSON.stringify(pool.fixedItems)}`);
  if (pool.generatedProductionItems !== 100) fail(`runtimePool.generatedProductionItems must be 100 at production depth 4; got ${JSON.stringify(pool.generatedProductionItems)}`);
  if (pool.totalProductionItems !== 192) fail(`runtimePool.totalProductionItems must be 192; got ${JSON.stringify(pool.totalProductionItems)}`);

  if (!Array.isArray(manifest.verifiedPaths) || manifest.verifiedPaths.length === 0) {
    fail('verifiedPaths must be a non-empty array of path objects');
  } else {
    for (const [index, entry] of manifest.verifiedPaths.entries()) {
      if (!isPlainObject(entry)) {
        fail(`verifiedPaths[${index}] must be an object, not ${typeof entry}`);
        continue;
      }
      assertNoPlaceholder(`verifiedPaths[${index}].path`, entry.path);
      assertRegex(`verifiedPaths[${index}].sha256`, entry.sha256, /^[a-f0-9]{64}$/i, '64 hex chars');
      assertRegex(`verifiedPaths[${index}].gitBlobSha`, entry.gitBlobSha, /^[a-f0-9]{40}$/i, '40 hex chars');
      if (!Number.isInteger(entry.bytes) || entry.bytes <= 0) fail(`verifiedPaths[${index}].bytes must be a positive integer`);
      validateLocalPath(entry);
    }
  }

  const hasGit = repoHasGit(root);
  if (!hasGit && !allowZipOnly) {
    fail('Cannot certify Git provenance because .git is not present. Re-run in a repository clone, or use --allow-zip-only-shape-check for non-certifying shape checks.');
  }
  if (hasGit && Array.isArray(manifest.verifiedPaths)) {
    for (const entry of manifest.verifiedPaths) {
      if (isPlainObject(entry) && typeof entry.path === 'string') {
        validateVerifiedPathAtCommit(gitSource.commitSha, entry);
      }
    }
  }

  const local = manifest.localVerification || {};
  assertNoPlaceholder('localVerification.command', local.command);
  if (local.command !== 'npm run verify:punctuation-qg:p10') fail(`localVerification.command must be "npm run verify:punctuation-qg:p10"; got ${JSON.stringify(local.command)}`);
  if (local.status !== 'pass') fail(`localVerification.status must be pass for certification; got ${JSON.stringify(local.status)}`);
  if (local.exitCode !== 0) fail(`localVerification.exitCode must be 0; got ${JSON.stringify(local.exitCode)}`);
  assertRegex('localVerification.nodeVersion', local.nodeVersion, /^v?22\.\d+\.\d+$/, 'exact Node 22 version, not 22.x');
  assertRegex('localVerification.npmVersion', local.npmVersion, /^\d+\.\d+\.\d+$/, 'exact npm version');
  if (!Number.isInteger(local.logicalGates) || local.logicalGates < 47) fail(`localVerification.logicalGates must be at least 47; got ${JSON.stringify(local.logicalGates)}`);
  assertNoPlaceholder('localVerification.completedAt', local.completedAt);
  assertNoPlaceholder('localVerification.logPath', local.logPath);
  assertRegex('localVerification.logSha256', local.logSha256, /^[a-f0-9]{64}$/i, '64 hex chars');

  const review = manifest.review || {};
  const ai = review.aiPreReview || {};
  const human = review.humanAcceptance || {};
  if (ai.status !== 'complete') fail(`review.aiPreReview.status must be complete; got ${JSON.stringify(ai.status)}`);
  if (ai.itemDecisions !== 192) fail(`review.aiPreReview.itemDecisions must be 192; got ${JSON.stringify(ai.itemDecisions)}`);
  if (ai.reviewRequiredClusterDecisions !== 47) fail(`review.aiPreReview.reviewRequiredClusterDecisions must be 47; got ${JSON.stringify(ai.reviewRequiredClusterDecisions)}`);

  const claimsCertified = ['CERTIFIED_PRE_DEPLOY', 'CERTIFIED_POST_DEPLOY', 'DEPTH6_BLOCKED_BUT_DEPTH4_CERTIFIED'].includes(manifest.certificationStatus);
  if (claimsCertified) {
    if (human.status !== 'complete') fail('humanAcceptance.status must be complete before any certified production status');
    assertNoPlaceholder('humanAcceptance.reviewer', human.reviewer);
    assertNoPlaceholder('humanAcceptance.role', human.role);
    assertNoPlaceholder('humanAcceptance.reviewedAt', human.reviewedAt);
    if (human.acceptedItems !== 192) fail(`humanAcceptance.acceptedItems must be 192; got ${JSON.stringify(human.acceptedItems)}`);
    if (human.acceptedReviewRequiredClusters !== 47) fail(`humanAcceptance.acceptedReviewRequiredClusters must be 47; got ${JSON.stringify(human.acceptedReviewRequiredClusters)}`);
    if (Array.isArray(human.blockers) && human.blockers.length > 0) fail(`humanAcceptance.blockers must be empty for certification; got ${human.blockers.length}`);
  }

  const smoke = manifest.liveProductionSmoke || {};
  assertOneOf('liveProductionSmoke.status', smoke.status, ['not_run', 'pass', 'fail']);
  if (manifest.certificationStatus === 'CERTIFIED_POST_DEPLOY' && smoke.status !== 'pass') {
    fail('CERTIFIED_POST_DEPLOY requires liveProductionSmoke.status pass');
  }
  if (smoke.status === 'pass') {
    assertNoPlaceholder('liveProductionSmoke.environment', smoke.environment);
    assertNoPlaceholder('liveProductionSmoke.origin', smoke.origin);
    assertNoPlaceholder('liveProductionSmoke.releaseId', smoke.releaseId);
    assertRegex('liveProductionSmoke.deployedCommitSha', smoke.deployedCommitSha, /^[a-f0-9]{40}$/i, '40 hex chars');
    assertNoPlaceholder('liveProductionSmoke.completedAt', smoke.completedAt);
    assertNoPlaceholder('liveProductionSmoke.artefactPath', smoke.artefactPath);
    assertRegex('liveProductionSmoke.artefactSha256', smoke.artefactSha256, /^[a-f0-9]{64}$/i, '64 hex chars');
    if (smoke.result !== 'pass') fail(`liveProductionSmoke.result must be pass when status is pass; got ${JSON.stringify(smoke.result)}`);
  }

  const depth6 = manifest.depth6 || {};
  if (pool.productionDepth > 4 && depth6.status !== 'complete') {
    fail('productionDepth above 4 requires depth6.status complete');
  }
}

if (warnings.length > 0) {
  console.error('\nWarnings:');
  for (const message of warnings) console.error(`  - ${message}`);
}

if (errors.length > 0) {
  console.error('\nPunctuation QG certification evidence: FAIL');
  for (const message of errors) console.error(`  - ${message}`);
  process.exit(1);
}

console.log('Punctuation QG certification evidence: PASS');
