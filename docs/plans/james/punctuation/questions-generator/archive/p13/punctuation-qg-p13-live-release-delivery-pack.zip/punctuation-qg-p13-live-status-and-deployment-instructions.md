# Punctuation QG P13 — Live Status and Deployment Instructions

## Status

P13 is source-ready and deployment-gated, not deployed by this ChatGPT environment.

The current production evidence I could inspect proves P11, not P13:

- production origin: `https://ks2.eugnel.uk`
- observed Punctuation release: `punctuation-qg-p11-2026-05-01`
- observed runtime items: `1268`
- observed generated depth: `40`
- observed `workerCommitSha`: `null`

P13 requires production to serve the P12 3000+ pool:

- content release id: `punctuation-qg-p12-3000-2026-05-02`
- phase: `punctuation-qg-p13-live-serving`
- fixed items: `512`
- generated items: `2800`
- runtime items: `3312`
- generated depth: `100`

## What this P13 pack provides

This pack adds the missing deploy/smoke/certification machinery:

- P13 add-on patch after P12.
- P13 combined patch from the uploaded `ks2-mastery-lean-05012344.zip` snapshot.
- P13 replacement files ZIP after P12.
- P13 combined replacement files ZIP including P12 + P13 files.
- P13 six-question live Smart Practice smoke.
- P13 live evidence validator.
- P13 predeploy verifier.
- P13 deployment wrapper.
- Updated Punctuation production smoke expectations so they are no longer stale at P11 counts.
- Updated Punctuation service tests for 512 fixed / 2800 generated / 3312 runtime.

## Local verification completed in this environment

From the extracted lean ZIP with the P12 replacement files and P13 add-on applied:

```text
npm run verify:punctuation-qg:p13-predeploy
```

Result:

```text
ok: true
node: v22.16.0
contentReleaseId: punctuation-qg-p12-3000-2026-05-02
productionDepth: 100
fixedItems: 512
generatedItems: 2800
runtimeItems: 3312
generatedFamilies: 28
templatesPerFamilyMin: 100
templatesPerFamilyMax: 100
```

The verifier ran:

```text
npm run verify:punctuation-qg:p12
node --test tests/punctuation-release-smoke.test.js tests/punctuation-service.test.js tests/worker-punctuation-runtime.test.js tests/punctuation-qg-p13-live-release.test.js
```

Both command groups passed.

## Deployment command

Run this inside the real repository checkout after applying P12 + P13 and with Cloudflare/GitHub deployment credentials available:

```bash
npm run deploy:punctuation-qg:p13 -- --commit-sha <deployed-commit-sha>
```

The wrapper runs:

```bash
npm run verify:punctuation-qg:p13-predeploy
npm run deploy
node scripts/punctuation-qg-p13-live-smoke.mjs \
  --env production \
  --authenticated \
  --origin https://ks2.eugnel.uk \
  --commit-sha <deployed-commit-sha> \
  --out reports/punctuation/punctuation-qg-p13-production-smoke.json
node scripts/validate-punctuation-qg-p13-live-evidence.mjs reports/punctuation/punctuation-qg-p13-production-smoke.json
```

## P13 live-serving certification gate

P13 is certified live only when `reports/punctuation/punctuation-qg-p13-production-smoke.json` validates with:

```text
ok: true
origin: https://ks2.eugnel.uk
attestation.environment: production
attestation.releasePhase: punctuation-qg-p13-live-serving
attestation.releaseId: punctuation-qg-p12-3000-2026-05-02
attestation.runtimeItemCount: 3312
attestation.generatedDepth: 100
attestation.workerCommitSha OR workerVersionId OR deploymentId: present
attestation.authenticatedCoverage: true
punctuation.productionObserved.runtimeItems: 3312
punctuation.smartSix.summaryTotal: 6
punctuation.smartSix.uniqueItems: 6
punctuation.smartSix.immediateRepeats: 0
punctuation.smartSix.generatedSeen: at least 1
```

## Honest production claim after deployment

Only after the live smoke validator passes:

> Punctuation QG P13 is live-serving certified for the P12 3000+ content pool on `https://ks2.eugnel.uk`: production is serving 3312 runtime items, including 512 fixed and 2800 generated items, at generated depth 100, with a six-question Smart Practice command-path smoke and deployed identity recorded.

## What must not be claimed yet

Do not claim P13 is live if production still reports P11 / 1268 items.

Do not claim P13 is live if the smoke artefact has `workerCommitSha: null` and no alternative deployment identity.

Do not claim P13 is live if the smoke only proves a one-item Smart path.

Do not claim Admin Hub production coverage unless admin credentials are used and the artefact records it.
