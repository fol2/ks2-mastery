# Punctuation QG P13 — 廣東話簡報

我已經幫你做咗 P13 live release pack，但要直講：我呢個環境無 GitHub write 權限、無 Cloudflare deploy credential，所以我唔可以真係幫你撳掣 deploy 上 production。可以做到嘅，我已經做咗：P12 source pool 套入 ZIP、修 P11 舊 count 測試、加 P13 deploy wrapper、加 live smoke、加 live evidence validator、加 predeploy gate，並喺本地跑過 predeploy，結果係 pass。

而家 production 上已知證據仍然係 P11：`https://ks2.eugnel.uk` 有 smoke artefact 顯示 1268 runtime items、generated depth 40、release id `punctuation-qg-p11-2026-05-01`，而且 `workerCommitSha` 係 null。呢個唔係 P13。

P13 要證明嘅係 production 真係 serving P12 3000+ pool：512 fixed、2800 generated、總共 3312 runtime items、generated depth 100。

今次 P13 pack 最大修正係：

1. 舊 production smoke script 仲有 P11 hardcoded counts：148 fixed / 1120 generated / 1268 runtime。P13 已改成由 active runtime manifest 自動計，避免 deploy 咗 P12 反而 smoke 因舊 count fail。
2. 舊 service tests 仍然 expect P11 count。P13 已改成 expect 512 / 2800 / 3312。
3. P11 live smoke 只係 one-item Smart smoke。P13 加咗 six-question live Smart smoke，要真正喺 production 做 6 題、6 unique items、0 immediate repeat，先可以叫 live-serving。
4. P11 smoke `workerCommitSha` 係 null。P13 validator 要求有 worker commit SHA、worker version id 或 deployment id，否則唔畀 claim deployed identity。

本地 predeploy gate 已 pass：

```text
npm run verify:punctuation-qg:p13-predeploy
ok: true
runtimeItems: 3312
fixedItems: 512
generatedItems: 2800
productionDepth: 100
```

下一步 dev 要喺真 repo + Cloudflare credential 入面跑：

```bash
npm run deploy:punctuation-qg:p13 -- --commit-sha <deployed-commit-sha>
```

跑完要有：

```text
reports/punctuation/punctuation-qg-p13-production-smoke.json
```

呢份 live smoke 如果 validate pass，先可以對外講：P13 live and serving。

一句講晒：P13 pack 已經準備好 deploy；我唔會假裝已經 live。真正 live 要由有 Cloudflare deploy 權限嘅環境跑 P13 deploy wrapper，然後用 P13 smoke artefact 證明 production 係 3312 題。
