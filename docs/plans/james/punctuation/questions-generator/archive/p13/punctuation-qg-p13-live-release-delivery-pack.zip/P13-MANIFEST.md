# Punctuation QG P13 Delivery Pack Manifest

## Core source artefacts

- `punctuation-qg-p13-addon-after-p12.patch` — small patch to apply after P12.
- `punctuation-qg-p13-combined-from-05012344.patch` — combined P12 + P13 patch from uploaded `ks2-mastery-lean-05012344.zip` snapshot.
- `punctuation-qg-p13-addon-files.zip` — replacement files for P13 after P12.
- `punctuation-qg-p13-combined-replacement-files.zip` — replacement files including P12 + P13.

## Contract and status

- `punctuation-qg-p13-live-release-contract.md`
- `punctuation-qg-p13-live-status-and-deployment-instructions.md`
- `punctuation-qg-p13-cantonese-brief.md`

## Evidence and test output

- `punctuation-qg-p13-predeploy-evidence.json`
- `punctuation-qg-p13-production-smoke.template.json`
- `p13-predeploy-full-output.txt`
- `p13-live-release-test-output.txt`
- `p13-release-smoke-source-tests-after.txt`
- `p13-artifacts-sha256.txt`
- `p13-addon-zip-test.txt`
- `p13-combined-zip-test.txt`

## Important boundary

This pack is not live production proof. It is source-ready and deploy-ready. Production is P13-certified only after the generated live smoke artefact validates successfully.
