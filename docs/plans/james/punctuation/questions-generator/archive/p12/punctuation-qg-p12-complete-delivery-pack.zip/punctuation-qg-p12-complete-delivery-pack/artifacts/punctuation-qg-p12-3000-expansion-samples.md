# Punctuation QG P12 — Sample Questions

These samples are drawn from the patched 3,312-item runtime pool. They are for human review of surface variety, not the full inventory.

## apostrophe_contractions

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| ac_choose_contractions | fixed | choose | Choose the best punctuated sentence. |  | She didnt know we'd already left. / ✓ She didn't know we'd already left. / She didn't know wed already left. / She didnt know we'd already left |
| ac_insert_contractions | fixed | insert | Add the punctuation needed. | Youll see that Im ready because Ive packed already. | You'll see that I'm ready because I've packed already. |
| ac_fix_contractions | fixed | fix | Correct the punctuation in this sentence. | I cant believe were nearly there. | I can't believe we're nearly there. |
| ac_transfer_contractions | fixed | transfer | Write one sentence that includes both can't and we're. |  | We can't leave yet because we're still tidying up. |
| ac_choose_theyre_dont | fixed | choose | Choose the sentence with both contractions punctuated correctly. |  | Theyre sure we dont need tickets. / ✓ They're sure we don't need tickets. / They're sure we dont need tickets. / Theyre sure we don't need tickets. |
| ac_insert_well_youre | fixed | insert | Add the apostrophes needed for the contractions. | Well check that youre ready before we leave. | We'll check that you're ready before we leave. |
| ac_transfer_dont_theyre | fixed | transfer | Write one sentence that includes both don't and they're. |  | Don't worry because they're on the way. |
| pg_apostrophe_mix | fixed | paragraph | Repair the apostrophes in the short passage. | We cant find the childrens coats. The girls bags are in the hall. | We can't find the children's coats. The girls' bags are in the hall. |

## apostrophe_possession

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| ap_choose_possession | fixed | choose | Choose the best punctuated sentence. |  | ✓ The teachers' room was next to the library. / The teacher's room was next to the librarys. / The teachers room was next to the library. / The teachers' room was next to the library |
| ap_insert_singular | fixed | insert | Add the missing punctuation. | The girls coat was hanging on the peg. | The girl's coat was hanging on the peg. |
| ap_fix_irregular | fixed | fix | Correct the punctuation in this sentence. | The childrens boots were lined up by the door. | The children's boots were lined up by the door. |
| ap_transfer_possession | fixed | transfer | Write one sentence that includes both children's and teachers'. |  | The children's paintings were hanging beside the teachers' notices. |
| fx_ap_choose_girls_bag | fixed | choose | Choose the sentence showing one girl owns the bag. |  | The girls bag was red. / ✓ The girl's bag was red. / The girls' bag was red. / The girl,s bag was red. |
| fx_ap_choose_children_books | fixed | choose | Choose the sentence showing the children own the books. |  | The childrens books were new. / ✓ The children's books were new. / The childrens' books were new. / The children,s books were new. |
| fx_ap_choose_teachers_room | fixed | choose | Choose the sentence showing several teachers share the room. |  | The teachers room was quiet. / The teacher's room was quiet. / ✓ The teachers' room was quiet. / The teacher,s room was quiet. |
| fx_ap_choose_boys_team | fixed | choose | Choose the sentence showing several boys own the team shirts. |  | The boys shirts were blue. / The boy's shirts were blue. / ✓ The boys' shirts were blue. / The boys, shirts were blue. |

## bullet_points

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| bp_choose_bring | fixed | choose | Choose the correctly punctuated bullet list. |  | ✓ Bring: / - a drink / - a hat / - a sketchbook / Bring / - a drink / - a hat / - a sketchbook / Bring: / - a drink. / - a hat / - a sketchbook. / Bring: / - a drink / - a hat / - a sketchbook. |
| bp_insert_kit | fixed | insert | Add the punctuation needed before the bullet list. | Bring / - a drink / - a hat / - a sketchbook | Bring: / - a drink / - a hat / - a sketchbook |
| bp_fix_consistency | fixed | fix | Make the bullet punctuation consistent. | Bring: / - a drink. / - a hat / - a sketchbook. | Bring: / - a drink / - a hat / - a sketchbook |
| bp_transfer_class | fixed | transfer | Write a bullet list with the stem Bring: and these exact items: a drink, a hat, a sketchbook. |  | Bring: / - a drink / - a hat / - a sketchbook |
| pg_bullet_consistency | fixed | paragraph | Repair the bullet-list punctuation. | Bring / - a drink. / - a hat / - a sketchbook. | Bring: / - a drink / - a hat / - a sketchbook |
| fx_bp_choose_parallel | fixed | choose | Choose the set where every bullet starts in the same grammatical pattern. |  | - bring a coat / - packed your lunch / - walking quietly / ✓ - bring a coat / - bring your lunch / - bring a notebook / - a coat / - bring your lunch / - quietly walking / - bring a coat; / - bring your lunch; / - bring a notebook, |
| fx_bp_choose_capitals | fixed | choose | Choose the bullet list with consistent punctuation. |  | ✓ - Pack your bag. / - Check your shoes. / - Close the door. / - Pack your bag / - check your shoes. / - Close the door / - Pack your bag, / - Check your shoes. / - Close the door / Pack your bag. / Check your shoes. / Close the door. |
| fx_bp_choose_notes | fixed | choose | Choose the clearest bullet list. |  | ✓ Remember to: / - bring water / - wear trainers / - arrive early / Remember to: / bring water / wear trainers / arrive early / Remember to / - bring water, / - wear trainers. / - arrive early? / Remember to: / - bring water. / - wear trainers, / - arrive early; |

## colon_list

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| cl_choose_supplies | fixed | choose | Choose the sentence where the colon introduces the list correctly. |  | We needed three things, a torch, a map and a whistle. / ✓ We needed three things: a torch, a map and a whistle. / We needed: three things a torch, a map and a whistle. / We needed three things a torch, a map and a whistle. |
| cl_insert_awards | fixed | insert | Add the colon before the list. | The team won three awards player of the match, best defence and fair play. | The team won three awards: player of the match, best defence and fair play. |
| cl_fix_camp | fixed | fix | Correct the punctuation before the list. | We packed three things, tents, food and torches. | We packed three things: tents, food and torches. |
| cl_transfer_trip | fixed | transfer | Write one sentence using this exact opening and list: We needed three things / a torch, a map and a whistle. |  | We needed three things: a torch, a map and a whistle. |
| cl_lc_transfer_toolkit | fixed | transfer | Write one sentence using this exact stem and list after a colon: Our toolkit contained three items / glue, card and scissors. |  | Our toolkit contained three items: glue, card and scissors. |
| cl_combine_awards | fixed | combine | Combine the opening clause and list using a colon. | The team won three awards / player of the match / best defence / fair play | The team won three awards: player of the match, best defence and fair play. |
| pg_colon_semicolon | fixed | paragraph | Repair the punctuation in the short passage. | The kit included three tools, a torch, a rope and a map. The weather changed, the team packed quickly. | The kit included three tools: a torch, a rope and a map. The weather changed; the team packed quickly. |
| fx_cl_choose_supplies | fixed | choose | Choose the sentence where the colon introduces the list. |  | ✓ We needed three things: rope, tape and chalk. / We needed three things, rope, tape and chalk. / We needed three things; rope, tape and chalk. / We needed: three things rope, tape and chalk. |

## comma_clarity

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| cc_choose_grandma | fixed | choose | Choose the sentence where the comma makes the meaning clear. |  | Let's eat Grandma. / ✓ Let's eat, Grandma. / Lets eat, Grandma. / Let's, eat Grandma. |
| cc_insert_time_travellers | fixed | insert | Add the comma that makes the meaning clear. | Most of the time travellers worry about delays. | Most of the time, travellers worry about delays. |
| cc_fix_when_rain_stopped | fixed | fix | Correct the punctuation so the sentence is clear. | When the rain stopped the children cheered. | When the rain stopped, the children cheered. |
| cc_transfer_morning | fixed | transfer | Write one sentence that begins with 'In the morning,' and uses the comma to make the meaning clear. |  | In the morning, the path was quiet. |
| cc_choose_before_cooking | fixed | choose | Choose the sentence where the comma makes the meaning clear. |  | Before cooking children wash their hands. / ✓ Before cooking, children wash their hands. / Before cooking children, wash their hands. / Before, cooking children wash their hands. |
| cc_insert_after_supper | fixed | insert | Add the comma that makes the meaning clear. | After supper we read quietly. | After supper, we read quietly. |
| cc_fix_if_lost | fixed | fix | Correct the punctuation so the sentence is clear. | If you get lost ask a helper. | If you get lost, ask a helper. |
| cc_transfer_after_the_match | fixed | transfer | Write one sentence that begins with 'After the match,' and uses the comma to make the meaning clear. |  | After the match, the team shook hands. |

## dash_clause

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| dc_choose_flooded_route | fixed | choose | Choose the best punctuated sentence. |  | The path was flooded, we took the longer route. / ✓ The path was flooded – we took the longer route. / The path was flooded –and we took the longer route. / The path was flooded we took the longer route. |
| dc_insert_door_froze | fixed | insert | Add the punctuation between the related clauses. | The door creaked open we froze. | The door creaked open – we froze. |
| dc_fix_signal_team | fixed | fix | Correct the dash punctuation in this sentence. | The signal failed –and the team waited. | The signal failed – the team waited. |
| dc_transfer_flooded_route | fixed | transfer | Write one sentence that links these clauses with a dash: The path was flooded / we took the longer route. |  | The path was flooded – we took the longer route. |
| dc_combine_flooded_route | fixed | combine | Combine the two related clauses into one sentence with a dash. | The path was flooded. / We took the longer route. | The path was flooded – we took the longer route. |
| dc_choose_lights_out | fixed | choose | Choose the sentence where the dash marks a clear break between ideas. |  | The lights went out, everyone stayed still. / ✓ The lights went out – everyone stayed still. / The lights went out –and everyone stayed still. / The lights went out everyone stayed still. |
| dc_insert_alarm_rang | fixed | insert | Add the dash between the related ideas. | The alarm rang everyone lined up. | The alarm rang – everyone lined up. |
| dc_transfer_curtain_rose | fixed | transfer | Write one sentence that links these ideas with a dash: The curtain rose / the hall fell silent. |  | The curtain rose – the hall fell silent. |

## fronted_adverbial

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| fa_choose_before_lunch | fixed | choose | Choose the best punctuated sentence. |  | Before lunch we finished the poster. / ✓ Before lunch, we finished the poster. / Before, lunch we finished the poster. / Before lunch we, finished the poster. |
| fa_insert_without_warning | fixed | insert | Add the missing punctuation after the fronted adverbial. | Without warning the bell began to ring. | Without warning, the bell began to ring. |
| fa_fix_at_last | fixed | fix | Correct the punctuation in this sentence. | At last we reached the harbour. | At last, we reached the harbour. |
| fa_transfer_after_lunch | fixed | transfer | Write one sentence that begins with 'After lunch,' and uses the comma correctly. |  | After lunch, we practised our lines. |
| fa_combine_after_storm | fixed | combine | Combine the adverbial and main clause into one sentence. | After the storm / The playground gleamed. | After the storm, the playground gleamed. |
| pg_fronted_speech | fixed | paragraph | Repair the punctuation in the short passage. | After lunch Mia asked can we start now | After lunch, Mia asked, "Can we start now?" |
| fx_fa_choose_before_assembly | fixed | choose | Choose the sentence with the comma after the fronted adverbial. |  | Before assembly we practised the song. / ✓ Before assembly, we practised the song. / Before, assembly we practised the song. / Before assembly we, practised the song. |
| fx_fa_choose_after_the_rain | fixed | choose | Choose the correctly punctuated sentence. |  | After the rain the playground dried quickly. / ✓ After the rain, the playground dried quickly. / After, the rain the playground dried quickly. / After the rain the playground, dried quickly. |

## hyphen

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| hy_choose_shark | fixed | choose | Choose the sentence where the hyphen avoids ambiguity. |  | We saw a man eating shark. / ✓ We saw a man-eating shark. / We saw a man-eating, shark. / We saw a man eating-shark. |
| hy_insert_little_used | fixed | insert | Add the hyphen that avoids ambiguity. | The little used room was locked. | The little-used room was locked. |
| hy_fix_fast_moving | fixed | fix | Correct the hyphenation in this sentence. | We watched a fast moving train. | We watched a fast-moving train. |
| hy_transfer_well_known | fixed | transfer | Write one sentence that includes this exact phrase: well-known author. |  | The well-known author visited our class. |
| hy_transfer_man_eating_shark | fixed | transfer | Write one sentence that includes this exact phrase: man-eating shark. |  | The divers spotted a man-eating shark near the reef. |
| hy_choose_small_business | fixed | choose | Choose the sentence where the hyphen avoids ambiguity. |  | The small business owner thanked us. / ✓ The small-business owner thanked us. / The small business-owner thanked us. / The small-business, owner thanked us. |
| hy_insert_well_behaved | fixed | insert | Add the hyphen that avoids ambiguity. | The well behaved puppy waited by the gate. | The well-behaved puppy waited by the gate. |
| hy_transfer_part_time_job | fixed | transfer | Write one sentence that includes this exact phrase: part-time job. |  | My sister found a part-time job at the library. |

## list_commas

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| lc_choose_picnic | fixed | choose | Choose the best punctuated sentence. |  | We packed torches maps and water. / ✓ We packed torches, maps and water. / We packed torches, maps, and water. / We packed, torches maps and water. |
| lc_insert_supplies | fixed | insert | Add the missing list punctuation. | We needed pencils rulers and glue. | We needed pencils, rulers and glue. |
| lc_fix_display | fixed | fix | Correct the list punctuation in this sentence. | The display showed shells pebbles, and fossils. | The display showed shells, pebbles and fossils. |
| lc_transfer_trip | fixed | transfer | Write one sentence that uses this exact list: torches, maps and water. |  | For the trip, we packed torches, maps and water. |
| lc_transfer_bake_sale | fixed | transfer | Write one sentence using this exact stem and list: For the bake sale we needed eggs, flour, butter and sugar. For this question, do not put a comma before the final and. |  | For the bake sale we needed eggs, flour, butter and sugar. |
| lc_combine_trip_list | fixed | combine | Combine the notes into one correctly punctuated sentence. | We packed / - torches / - maps / - water | We packed torches, maps and water. |
| fx_lc_choose_sports_day | fixed | choose | Choose the list with the commas in the right places. |  | We carried cones hoops and beanbags. / ✓ We carried cones, hoops and beanbags. / We carried, cones hoops and beanbags. / We carried cones hoops, and beanbags. |
| fx_lc_choose_art_table | fixed | choose | Choose the best-punctuated list. |  | ✓ On the table were paints, brushes and paper. / On the table were paints brushes and paper. / On the table, were paints brushes and paper. / On the table were paints, brushes, and paper, |

## parenthesis

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| pa_choose_coach | fixed | choose | Choose the sentence where the parenthesis is marked correctly. |  | Mr Patel our coach arrived early. / ✓ Mr Patel, our coach, arrived early. / Mr Patel, our coach arrived early. / Mr Patel our coach, arrived early. |
| pa_insert_museum | fixed | insert | Add the punctuation for the parenthesis. | The museum a former station was busy. | The museum, a former station, was busy. |
| pa_fix_author | fixed | fix | Correct the parenthesis punctuation in this sentence. | The author, who won the prize smiled. | The author, who won the prize, smiled. |
| pa_transfer_library | fixed | transfer | Write one sentence using this exact frame and parenthesis: The library / which opened last year / is busy. |  | The library, which opened last year, is busy. |
| pa_combine_lighthouse | fixed | combine | Combine the sentence and extra detail using parenthesis. | The lighthouse guided the boats. / Extra detail: a useful lookout | The lighthouse, a useful lookout, guided the boats. |
| pg_parenthesis_speech | fixed | paragraph | Repair the punctuation in the short passage. | The museum a former station was busy. Noor said the queue is moving | The museum, a former station, was busy. Noor said, "The queue is moving." |
| fx_pa_choose_mrs_ali | fixed | choose | Choose the sentence with the parenthesis marked correctly. |  | Mrs Ali our guide smiled. / ✓ Mrs Ali, our guide, smiled. / Mrs Ali, our guide smiled. / Mrs Ali our guide, smiled. |
| fx_pa_choose_bridge | fixed | choose | Choose the sentence where extra information is bracketed correctly. |  | The bridge which was old crossed the stream. / ✓ The bridge, which was old, crossed the stream. / The bridge, which was old crossed the stream. / The bridge which was old, crossed the stream. |

## semicolon

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| sc_choose_rain_pitch | fixed | choose | Choose the best punctuated sentence. |  | The rain had stopped, the pitch was still slippery. / ✓ The rain had stopped; the pitch was still slippery. / The rain had stopped; and the pitch was still slippery. / The rain had stopped the pitch was still slippery. |
| sc_insert_lights_audience | fixed | insert | Add the punctuation between the related clauses. | The lights dimmed the audience fell silent. | The lights dimmed; the audience fell silent. |
| sc_fix_path_map | fixed | fix | Correct the punctuation between these related clauses. | The path was narrow, the map showed a safer route. | The path was narrow; the map showed a safer route. |
| sc_transfer_rain_pitch | fixed | transfer | Write one sentence that links these clauses with a semi-colon: The rain had stopped / the pitch was still slippery. |  | The rain had stopped; the pitch was still slippery. |
| sc_combine_rain_pitch | fixed | combine | Combine the two related clauses into one sentence with a semi-colon. | The rain had stopped. / The pitch was still slippery. | The rain had stopped; the pitch was still slippery. |
| fx_sc_choose_moon_clouds | fixed | choose | Choose the sentence where the semi-colon joins two related clauses. |  | ✓ The moon was bright; the clouds moved away. / The moon was bright, the clouds moved away. / The moon was bright; and the clouds moved away. / The moon; was bright the clouds moved away. |
| fx_sc_choose_team_tired | fixed | choose | Choose the best-punctuated sentence. |  | The team was tired, they kept running. / ✓ The team was tired; they kept running. / The team was tired; and they kept running. / The team; was tired they kept running. |
| fx_sc_choose_lights_dimmed | fixed | choose | Choose the sentence with the correct boundary punctuation. |  | ✓ The lights dimmed; the audience became silent. / The lights dimmed, the audience became silent. / The lights dimmed; and the audience became silent. / The lights; dimmed the audience became silent. |

## semicolon_list

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| sl_choose_cities | fixed | choose | Choose the sentence where semi-colons separate complex list items. |  | We visited York, England, Cardiff, Wales, and Belfast, Northern Ireland. / ✓ We visited York, England; Cardiff, Wales; and Belfast, Northern Ireland. / We visited York; England, Cardiff; Wales and Belfast; Northern Ireland. / We visited York, England; Cardiff, Wales, and Belfast, Northern Ireland. |
| sl_insert_cities | fixed | insert | Add semi-colons to separate the complex list items. | We visited York, England Cardiff, Wales and Belfast, Northern Ireland. | We visited York, England; Cardiff, Wales; and Belfast, Northern Ireland. |
| sl_fix_captains | fixed | fix | Correct the punctuation in this complex list. | Our captains were Sam, Year 5, Aisha, Year 6, and Noor, Year 6. | Our captains were Sam, Year 5; Aisha, Year 6; and Noor, Year 6. |
| sl_transfer_places | fixed | transfer | Write one sentence that separates this complex list with semi-colons: York, England / Cardiff, Wales / Belfast, Northern Ireland. |  | We visited York, England; Cardiff, Wales; and Belfast, Northern Ireland. |
| sl_choose_clubs | fixed | choose | Choose the sentence where semi-colons separate the larger list items. |  | The clubs met in Leeds, Yorkshire, Exeter, Devon, and Perth, Scotland. / ✓ The clubs met in Leeds, Yorkshire; Exeter, Devon; and Perth, Scotland. / The clubs met in Leeds; Yorkshire, Exeter; Devon and Perth; Scotland. / The clubs met in Leeds, Yorkshire; Exeter, Devon, and Perth, Scotland. |
| sl_insert_helper_roles | fixed | insert | Add semi-colons to separate the larger list items. | The helpers were Maya, register monitor Leo, equipment monitor and Aisha, line leader. | The helpers were Maya, register monitor; Leo, equipment monitor; and Aisha, line leader. |
| sl_fix_stalls | fixed | fix | Correct the punctuation in this complex list. | The stalls were crafts, table one, games, table two, and snacks, table three. | The stalls were crafts, table one; games, table two; and snacks, table three. |
| sl_transfer_event_stalls | fixed | transfer | Write one sentence that separates this complex list with semi-colons: crafts, table one / games, table two / snacks, table three. |  | The stalls were crafts, table one; games, table two; and snacks, table three. |

## sentence_endings

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| se_choose_exclaim | fixed | choose | Choose the best punctuated sentence. |  | What a fantastic goal. / ✓ What a fantastic goal! / what a fantastic goal! / What a fantastic goal |
| se_insert_question | fixed | insert | Punctuate the sentence accurately. | why was the hall still locked | Why was the hall still locked? |
| se_fix_statement | fixed | fix | Correct the punctuation in this sentence. | do not forget your reading journal? | Do not forget your reading journal. |
| se_transfer_why | fixed | transfer | Write one question that begins with 'Why' and ends correctly. |  | Why was the gate still open? |
| se_choose_direct_question | fixed | choose | Choose the best punctuated sentence. |  | Where is the science tray. / where is the science tray? / ✓ Where is the science tray? / Where is the science tray |
| se_insert_quiet_command | fixed | insert | Punctuate the instruction accurately. | please close the classroom door | Please close the classroom door. |
| se_fix_excited_statement | fixed | fix | Correct the punctuation so the sentence shows excitement. | what a clever idea. | What a clever idea! |
| se_transfer_where | fixed | transfer | Write one question that begins with 'Where' and ends correctly. |  | Where did the trail begin? |

## speech

| id | source | mode | prompt | stem | model/options |
|---|---|---|---|---|---|
| sp_choose_reporting_comma | fixed | choose | Choose the best punctuated sentence. |  | ✓ Mum said, "Put your shoes by the door." / Mum said "Put your shoes by the door". / Mum said, "Put your shoes by the door". / Mum said "Put your shoes by the door." |
| sp_insert_question | fixed | insert | Punctuate the direct speech accurately. | Ella asked can we start now | Ella asked, "Can we start now?" |
| sp_fix_question | fixed | fix | Correct the punctuation in this sentence. | "Where are we meeting"? asked Zara. | "Where are we meeting?" asked Zara. |
| sp_transfer_question | fixed | transfer | Write one sentence of direct speech using these exact spoken words: Can we start now? |  | Mia asked, "Can we start now?" |
| sp_fa_transfer_at_last_speech | fixed | transfer | Write one sentence using this exact opening, reporting clause and spoken words: At last / Noah shouted / we made it! |  | At last, Noah shouted, "We made it!" |
| fx_sp_choose_lucy_line | fixed | choose | Choose the correctly punctuated direct speech. |  | Lucy said "I found it." / ✓ Lucy said, "I found it." / Lucy said, "I found it". / Lucy said "I found it". |
| fx_sp_choose_question_inside | fixed | choose | Choose the sentence where the question mark is inside the speech. |  | "Can I help"? asked Omar. / ✓ "Can I help?" asked Omar. / "Can I help? asked Omar." / Can I help? asked Omar. |
| fx_sp_choose_command_inside | fixed | choose | Choose the correctly punctuated command in speech. |  | ✓ Dad called, "Close the gate." / Dad called "Close the gate". / Dad called, "Close the gate". / Dad called "Close the gate." |

