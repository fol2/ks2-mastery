# Punctuation QG P12 — 3000+ Expansion Samples

Release: `punctuation-qg-p12-3000-2026-05-02`
Runtime pool: 3312 items (512 fixed + 2800 generated)

## Generated family samples

### gen_apostrophe_contractions_fix
- **gen_apostrophe_contractions_fix_rq1kiz_1** [fix; apostrophe_contractions]
  - Prompt: Correct the missing apostrophe in the contraction.
  - Stem: we wont move the camera to the museum.
  - Model: we won't move the camera to the museum.
- **gen_apostrophe_contractions_fix_rg1yu0_2** [fix; apostrophe_contractions]
  - Prompt: Correct the missing apostrophe in the contraction.
  - Stem: I cant move the lantern to the library.
  - Model: I can't move the lantern to the library.
- **gen_apostrophe_contractions_fix_sa0rwx_3** [fix; apostrophe_contractions]
  - Prompt: Correct the missing apostrophe in the contraction.
  - Stem: you shouldnt move the sketchbook to the school office.
  - Model: you shouldn't move the sketchbook to the school office.

### gen_apostrophe_mix_paragraph
- **gen_apostrophe_mix_paragraph_dqfdrp_1** [paragraph; apostrophe_contractions, apostrophe_possession]
  - Prompt: Repair the apostrophes in the short passage.
  - Stem: you shouldnt forget the wildlife leaders clipboards. The box was beside the wildlife centre.
  - Model: you shouldn't forget the wildlife leaders' clipboards. The box was beside the wildlife centre.
- **gen_apostrophe_mix_paragraph_dgfs2q_2** [paragraph; apostrophe_contractions, apostrophe_possession]
  - Prompt: Repair the apostrophes in the short passage.
  - Stem: I cant forget the wildlife monitors posters. The box was beside the art studio.
  - Model: I can't forget the wildlife monitors' posters. The box was beside the art studio.
- **gen_apostrophe_mix_paragraph_d6g6dr_3** [paragraph; apostrophe_contractions, apostrophe_possession]
  - Prompt: Repair the apostrophes in the short passage.
  - Stem: youre ready to check the wildlife captains weather charts. The box was beside the archive room.
  - Model: you're ready to check the wildlife captains' weather charts. The box was beside the archive room.

### gen_apostrophe_possession_choose
- **gen_apostrophe_possession_choose_tqzigs_1** [choose; apostrophe_possession]
  - Prompt: Choose the sentence with the correct possessive apostrophe.
  - Stem: The lanterns belong to more than one astronomy monitor.
  - Model: The astronomy monitors' lanterns were ready in the library.
- **gen_apostrophe_possession_choose_u0z45r_2** [choose; apostrophe_possession]
  - Prompt: Choose the sentence with the correct possessive apostrophe.
  - Stem: The telescopes belong to more than one astronomy leader.
  - Model: The astronomy leaders' telescopes were ready in the art studio.
- **gen_apostrophe_possession_choose_uaypuq_3** [choose; apostrophe_possession]
  - Prompt: Choose the sentence with the correct possessive apostrophe.
  - Stem: The seed trays belong to more than one astronomy helper.
  - Model: The astronomy helpers' seed trays were ready in the castle tower.

### gen_apostrophe_possession_insert
- **gen_apostrophe_possession_insert_pnjfvs_1** [insert; apostrophe_possession]
  - Prompt: Add the apostrophe for possession.
  - Stem: The farm monitors badges were checked beside the playground.
  - Model: The farm monitors' badges were checked beside the playground.
- **gen_apostrophe_possession_insert_pxj1kr_2** [insert; apostrophe_possession]
  - Prompt: Add the apostrophe for possession.
  - Stem: The farm leaders footballs were checked beside the farmyard.
  - Model: The farm leaders' footballs were checked beside the farmyard.
- **gen_apostrophe_possession_insert_q7in9q_3** [insert; apostrophe_possession]
  - Prompt: Add the apostrophe for possession.
  - Stem: The farm helpers water bottles were checked beside the archive room.
  - Model: The farm helpers' water bottles were checked beside the archive room.

### gen_bullet_points_fix
- **gen_bullet_points_fix_1bqcpu6_1** [fix; bullet_points]
  - Prompt: Make the bullet punctuation consistent.
  - Stem: Library checklist: / - check the lantern. / - pack the notebook / - label the map.
  - Model: Library checklist: / - check the lantern. / - pack the notebook. / - label the map.
- **gen_bullet_points_fix_1c0cbj5_2** [fix; bullet_points]
  - Prompt: Make the bullet punctuation consistent.
  - Stem: Music room checklist: / - check the robot. / - pack the badge / - label the costume.
  - Model: Music room checklist: / - check the robot. / - pack the badge. / - label the costume.
- **gen_bullet_points_fix_1b6dig8_3** [fix; bullet_points]
  - Prompt: Make the bullet punctuation consistent.
  - Stem: Harbour checklist: / - check the poster. / - pack the sketchbook / - label the compass.
  - Model: Harbour checklist: / - check the poster. / - pack the sketchbook. / - label the compass.

### gen_bullet_points_paragraph
- **gen_bullet_points_paragraph_1gkgo9j_1** [paragraph; bullet_points]
  - Prompt: Repair the bullet-list punctuation.
  - Stem: Playground jobs / - carry the tablet / - clean the clipboard. / - return the seed tray
  - Model: Playground jobs: / - carry the tablet / - clean the clipboard / - return the seed tray
- **gen_bullet_points_paragraph_1gah2kk_2** [paragraph; bullet_points]
  - Prompt: Repair the bullet-list punctuation.
  - Stem: Science lab jobs / - carry the telescope / - clean the poster. / - return the sketchbook
  - Model: Science lab jobs: / - carry the telescope / - clean the poster / - return the sketchbook
- **gen_bullet_points_paragraph_1h4fvnh_3** [paragraph; bullet_points]
  - Prompt: Repair the bullet-list punctuation.
  - Stem: Garden jobs / - carry the drum / - clean the weather chart. / - return the rope
  - Model: Garden jobs: / - carry the drum / - clean the weather chart / - return the rope

### gen_colon_list_combine
- **gen_colon_list_combine_u06kwi_1** [combine; colon_list]
  - Prompt: Combine the opening clause and list using a colon.
  - Stem: The science lab club needed three resources / a compass / a tablet / a seed tray
  - Model: The science lab club needed three resources: a compass, a tablet and a seed tray.
- **gen_colon_list_combine_ua66lh_2** [combine; colon_list]
  - Prompt: Combine the opening clause and list using a colon.
  - Stem: The harbour club needed three resources / a clipboard / a raincoat / a ticket
  - Model: The harbour club needed three resources: a clipboard, a raincoat and a ticket.
- **gen_colon_list_combine_tg7dik_3** [combine; colon_list]
  - Prompt: Combine the opening clause and list using a colon.
  - Stem: The classroom club needed three resources / a football / a drum / a music stand
  - Model: The classroom club needed three resources: a football, a drum and a music stand.

### gen_colon_list_insert
- **gen_colon_list_insert_ndgxks_1** [insert; colon_list]
  - Prompt: Add the colon before the list.
  - Stem: The library team packed three items a lantern, a map and a robot.
  - Model: The library team packed three items: a lantern, a map and a robot.
- **gen_colon_list_insert_nngj9r_2** [insert; colon_list]
  - Prompt: Add the colon before the list.
  - Stem: The museum team packed three items a camera, a telescope and a microphone.
  - Model: The museum team packed three items: a camera, a telescope and a microphone.
- **gen_colon_list_insert_nxg4yq_3** [insert; colon_list]
  - Prompt: Add the colon before the list.
  - Stem: The garden team packed three items a costume, a tablet and a whistle.
  - Model: The garden team packed three items: a costume, a tablet and a whistle.

### gen_colon_semicolon_paragraph
- **gen_colon_semicolon_paragraph_hh7aao_1** [paragraph; colon_list, semicolon]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: The library team needed three things, a lantern, a map and a robot. The poster helped the class, the clay studio team made everyone smile.
  - Model: The library team needed three things: a lantern, a map and a robot. The poster helped the class; the clay studio team made everyone smile.
- **gen_colon_semicolon_paragraph_hr6vzn_2** [paragraph; colon_list, semicolon]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: The music room team needed three things, a badge, a sketchbook and a model bridge. The sketchbook surprised the judges, the fossil table team moved across the table.
  - Model: The music room team needed three things: a badge, a sketchbook and a model bridge. The sketchbook surprised the judges; the fossil table team moved across the table.
- **gen_colon_semicolon_paragraph_i16hom_3** [paragraph; colon_list, semicolon]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: The harbour team needed three things, a compass, a football and a pencil case. The compass needed careful repairs, the tool cupboard team looked bright in the sun.
  - Model: The harbour team needed three things: a compass, a football and a pencil case. The compass needed careful repairs; the tool cupboard team looked bright in the sun.

### gen_comma_clarity_insert
- **gen_comma_clarity_insert_akjlvk_1** [insert; comma_clarity]
  - Prompt: Add the comma that makes the meaning clear.
  - Stem: In the morning the robot followed the black line.
  - Model: In the morning, the robot followed the black line.
- **gen_comma_clarity_insert_auj7kj_2** [insert; comma_clarity]
  - Prompt: Add the comma that makes the meaning clear.
  - Stem: After supper the visitors waited by the gate.
  - Model: After supper, the visitors waited by the gate.
- **gen_comma_clarity_insert_b4it9i_3** [insert; comma_clarity]
  - Prompt: Add the comma that makes the meaning clear.
  - Stem: When the rain stopped the gardeners watered the seed trays.
  - Model: When the rain stopped, the gardeners watered the seed trays.

### gen_dash_clause_combine
- **gen_dash_clause_combine_8pysu6_1** [combine; dash_clause]
  - Prompt: Combine the two related clauses into one sentence with a dash.
  - Stem: The library signal changed. / Every astronomy monitors checked the lantern.
  - Model: The library signal changed – every astronomy monitors checked the lantern.
- **gen_dash_clause_combine_8zyej5_2** [combine; dash_clause]
  - Prompt: Combine the two related clauses into one sentence with a dash.
  - Stem: The harbour signal changed. / Every canoe leaders checked the sketchbook.
  - Model: The harbour signal changed – every canoe leaders checked the sketchbook.
- **gen_dash_clause_combine_85zlg8_3** [combine; dash_clause]
  - Prompt: Combine the two related clauses into one sentence with a dash.
  - Stem: The observatory signal changed. / Every drama helpers checked the whistle.
  - Model: The observatory signal changed – every drama helpers checked the whistle.

### gen_dash_clause_fix
- **gen_dash_clause_fix_t2e6k4_1** [fix; dash_clause]
  - Prompt: Add a dash between the related clauses.
  - Stem: The tablet helped the class the art gallery team impressed the visitors.
  - Model: The tablet helped the class – the art gallery team impressed the visitors.
- **gen_dash_clause_fix_tcds93_2** [fix; dash_clause]
  - Prompt: Add a dash between the related clauses.
  - Stem: The clipboard surprised the judges the covered walkway team guided the guests.
  - Model: The clipboard surprised the judges – the covered walkway team guided the guests.
- **gen_dash_clause_fix_tmddy2_3** [fix; dash_clause]
  - Prompt: Add a dash between the related clauses.
  - Stem: The seed tray needed careful repairs the clay studio team made the display clearer.
  - Model: The seed tray needed careful repairs – the clay studio team made the display clearer.

### gen_fronted_adverbial_combine
- **gen_fronted_adverbial_combine_1i2x6d_1** [combine; fronted_adverbial]
  - Prompt: Combine the adverbial and main clause into one sentence.
  - Stem: After the rehearsal near forest path / Maya found the missing badge.
  - Model: After the rehearsal near forest path, Maya found the missing badge.
- **gen_fronted_adverbial_combine_183bhe_2** [combine; fronted_adverbial]
  - Prompt: Combine the adverbial and main clause into one sentence.
  - Stem: Before sunrise near library / The guide counted the tickets.
  - Model: Before sunrise near library, the guide counted the tickets.
- **gen_fronted_adverbial_combine_0y3psf_3** [combine; fronted_adverbial]
  - Prompt: Combine the adverbial and main clause into one sentence.
  - Stem: During the storm near book corner / The visitors waited by the gate.
  - Model: During the storm near book corner, the visitors waited by the gate.

### gen_fronted_adverbial_fix
- **gen_fronted_adverbial_fix_jg60s7_1** [fix; fronted_adverbial]
  - Prompt: Correct the comma after the fronted adverbial.
  - Stem: After the rehearsal the guide counted the tickets.
  - Model: After the rehearsal, the guide counted the tickets.
- **gen_fronted_adverbial_fix_j66f38_2** [fix; fronted_adverbial]
  - Prompt: Correct the comma after the fronted adverbial.
  - Stem: Before sunrise we checked the spare batteries.
  - Model: Before sunrise, we checked the spare batteries.
- **gen_fronted_adverbial_fix_k05865_3** [fix; fronted_adverbial]
  - Prompt: Correct the comma after the fronted adverbial.
  - Stem: During the storm Maya found the missing badge.
  - Model: During the storm, Maya found the missing badge.

### gen_fronted_speech_paragraph
- **gen_fronted_speech_paragraph_b3c0j8_1** [paragraph; fronted_adverbial, speech]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: Before sunrise Ava asked can we start now?
  - Model: Before sunrise, Ava asked, "Can we start now?"
- **gen_fronted_speech_paragraph_bdbm87_2** [paragraph; fronted_adverbial, speech]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: During the storm Omar asked how far is the harbour?
  - Model: During the storm, Omar asked, "How far is the harbour?"
- **gen_fronted_speech_paragraph_bnb7x6_3** [paragraph; fronted_adverbial, speech]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: When the whistle blew Grace asked where should we meet?
  - Model: When the whistle blew, Grace asked, "Where should we meet?"

### gen_hyphen_insert
- **gen_hyphen_insert_1jysu8g_1** [insert; hyphen]
  - Prompt: Add the hyphen that avoids ambiguity.
  - Stem: The well known display helped the class in the library.
  - Model: The well-known display helped the class in the library.
- **gen_hyphen_insert_1k8sfxf_2** [insert; hyphen]
  - Prompt: Add the hyphen that avoids ambiguity.
  - Stem: The fast moving poster surprised the judges in the forest path.
  - Model: The fast-moving poster surprised the judges in the forest path.
- **gen_hyphen_insert_1kis1me_3** [insert; hyphen]
  - Prompt: Add the hyphen that avoids ambiguity.
  - Stem: The little used room needed careful repairs in the workshop.
  - Model: The little-used room needed careful repairs in the workshop.

### gen_list_commas_choose
- **gen_list_commas_choose_6zlidv_1** [choose; list_commas]
  - Prompt: Choose the sentence with commas used correctly in the list.
  - Stem: Pick the best punctuation for the sports hall collection list: cameras; drums; traffic signs.
  - Model: The sports hall display about notebooks included cameras, drums and traffic signs.
- **gen_list_commas_choose_6plwow_2** [choose; list_commas]
  - Prompt: Choose the sentence with commas used correctly in the list.
  - Stem: Pick the best punctuation for the library collection list: lanterns; raincoats; recipe cards.
  - Model: The library display about lanterns included lanterns, raincoats and recipe cards.
- **gen_list_commas_choose_7jkprt_3** [choose; list_commas]
  - Prompt: Choose the sentence with commas used correctly in the list.
  - Stem: Pick the best punctuation for the harbour collection list: sketchbooks; scripts; noticeboards.
  - Model: The harbour display about cameras included sketchbooks, scripts and noticeboards.

### gen_list_commas_combine
- **gen_list_commas_combine_16v421f_1** [combine; list_commas]
  - Prompt: Combine the notes into one correctly punctuated list sentence.
  - Stem: The museum kit contained / - telescopes / - pencil cases / - audio recorders
  - Model: The museum kit contained telescopes, pencil cases and audio recorders.
- **gen_list_commas_combine_16l4gcg_2** [combine; list_commas]
  - Prompt: Combine the notes into one correctly punctuated list sentence.
  - Stem: The music room kit contained / - robots / - tickets / - helmets
  - Model: The music room kit contained robots, tickets and helmets.
- **gen_list_commas_combine_17f39fd_3** [combine; list_commas]
  - Prompt: Combine the notes into one correctly punctuated list sentence.
  - Stem: The art studio kit contained / - clipboards / - glue sticks / - soil samples
  - Model: The art studio kit contained clipboards, glue sticks and soil samples.

### gen_list_commas_insert
- **gen_list_commas_insert_512njz_1** [insert; list_commas]
  - Prompt: Add commas to separate the list items.
  - Stem: The music room tray held sails lap counters and song sheets.
  - Model: The music room tray held sails, lap counters and song sheets.
- **gen_list_commas_insert_4r31v0_2** [insert; list_commas]
  - Prompt: Add commas to separate the list items.
  - Stem: The science lab tray held rucksacks bike pumps and calm jars.
  - Model: The science lab tray held rucksacks, bike pumps and calm jars.
- **gen_list_commas_insert_5l1uxx_3** [insert; list_commas]
  - Prompt: Add commas to separate the list items.
  - Stem: The forest path tray held reading logs memory cards and costumes.
  - Model: The forest path tray held reading logs, memory cards and costumes.

### gen_parenthesis_combine
- **gen_parenthesis_combine_zh6kpi_1** [combine; parenthesis]
  - Prompt: Combine the sentence and extra detail using parenthesis.
  - Stem: The science lab display helped the class. / Extra detail: opened by the drama leaders.
  - Model: The science lab display, opened by the drama leaders, helped the class.
- **gen_parenthesis_combine_zr66eh_2** [combine; parenthesis]
  - Prompt: Combine the sentence and extra detail using parenthesis.
  - Stem: The music room display kept everyone safe. / Extra detail: a collection of tablets.
  - Model: The music room display, a collection of tablets, kept everyone safe.
- **gen_parenthesis_combine_yx7dbk_3** [combine; parenthesis]
  - Prompt: Combine the sentence and extra detail using parenthesis.
  - Stem: The museum display showed the next step. / Extra detail: opened by the eco captains.
  - Model: The museum display, opened by the eco captains, showed the next step.

### gen_parenthesis_fix
- **gen_parenthesis_fix_1udhik_1** [fix; parenthesis]
  - Prompt: Add punctuation around the parenthesis.
  - Stem: The library project led by the astronomy monitors helped the class.
  - Model: The library project, led by the astronomy monitors, helped the class.
- **gen_parenthesis_fix_24d37j_2** [fix; parenthesis]
  - Prompt: Add punctuation around the parenthesis.
  - Stem: The sports hall project which used the badge welcomed the team.
  - Model: The sports hall project, which used the badge, welcomed the team.
- **gen_parenthesis_fix_2ecowi_3** [fix; parenthesis]
  - Prompt: Add punctuation around the parenthesis.
  - Stem: The playground project led by the canoe helpers solved the problem.
  - Model: The playground project, led by the canoe helpers, solved the problem.

### gen_parenthesis_speech_paragraph
- **gen_parenthesis_speech_paragraph_1jbis86_1** [paragraph; parenthesis, speech]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: The library room which stored the lantern helped the class. Ava shouted what a brilliant save!
  - Model: The library room, which stored the lantern, helped the class. Ava shouted, "What a brilliant save!"
- **gen_parenthesis_speech_paragraph_1jlidx5_2** [paragraph; parenthesis, speech]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: The playground room which stored the costume looked bright in the sun. Zara asked where should we meet?
  - Model: The playground room, which stored the costume, looked bright in the sun. Zara asked, "Where should we meet?"
- **gen_parenthesis_speech_paragraph_1irjku8_3** [paragraph; parenthesis, speech]
  - Prompt: Repair the punctuation in the short passage.
  - Stem: The theatre room which stored the tablet made the hall quieter. Ruby asked where are the costumes?
  - Model: The theatre room, which stored the tablet, made the hall quieter. Ruby asked, "Where are the costumes?"

### gen_semicolon_combine
- **gen_semicolon_combine_vkgq33_1** [combine; semicolon]
  - Prompt: Combine the two related clauses into one sentence with a semi-colon.
  - Stem: The badge surprised the judges. / The outdoor shelter team helped younger pupils.
  - Model: The badge surprised the judges; the outdoor shelter team helped younger pupils.
- **gen_semicolon_combine_vah4e4_2** [combine; semicolon]
  - Prompt: Combine the two related clauses into one sentence with a semi-colon.
  - Stem: The robot helped the class. / The tool cupboard team kept everyone safe.
  - Model: The robot helped the class; the tool cupboard team kept everyone safe.
- **gen_semicolon_combine_w4fxh1_3** [combine; semicolon]
  - Prompt: Combine the two related clauses into one sentence with a semi-colon.
  - Stem: The telescope stayed open all day. / The museum team won first prize.
  - Model: The telescope stayed open all day; the museum team won first prize.

### gen_semicolon_fix
- **gen_semicolon_fix_1ftebmd_1** [fix; semicolon]
  - Prompt: Replace the comma splice with a semi-colon.
  - Stem: The notebook surprised the judges, the museum team guided the guests.
  - Model: The notebook surprised the judges; the museum team guided the guests.
- **gen_semicolon_fix_1fjepxe_2** [fix; semicolon]
  - Prompt: Replace the comma splice with a semi-colon.
  - Stem: The lantern helped the class, the library team impressed the visitors.
  - Model: The lantern helped the class; the library team impressed the visitors.
- **gen_semicolon_fix_1f9f48f_3** [fix; semicolon]
  - Prompt: Replace the comma splice with a semi-colon.
  - Stem: The camera stayed open all day, the school office team showed the next step.
  - Model: The camera stayed open all day; the school office team showed the next step.

### gen_semicolon_list_fix
- **gen_semicolon_list_fix_1sqki6m_1** [fix; semicolon_list]
  - Prompt: Use semi-colons to separate the complex list items.
  - Stem: The helpers were Ava, captain, Year 5, Jack, leader, choir and Arlo, speaker, debate club.
  - Model: The helpers were Ava, captain, Year 5; Jack, leader, choir; and Arlo, speaker, debate club.
- **gen_semicolon_list_fix_1t0k3vl_2** [fix; semicolon_list]
  - Prompt: Use semi-colons to separate the complex list items.
  - Stem: The route cards named science lab, Cardiff, Wales, observatory, Bath, England and kitchen, Inverness, Scotland.
  - Model: The route cards named science lab, Cardiff, Wales; observatory, Bath, England; and kitchen, Inverness, Scotland.
- **gen_semicolon_list_fix_1s6laso_3** [fix; semicolon_list]
  - Prompt: Use semi-colons to separate the complex list items.
  - Stem: The helpers were Maya, runner, sports team, Oscar, speaker, debate club and Daniel, chef, cookery class.
  - Model: The helpers were Maya, runner, sports team; Oscar, speaker, debate club; and Daniel, chef, cookery class.

### gen_sentence_endings_choose
- **gen_sentence_endings_choose_gxxlxq_1** [choose; sentence_endings]
  - Prompt: Choose the correctly punctuated sentence.
  - Stem: Choose the best ending for: where is the spare key
  - Model: Where is the spare key?
- **gen_sentence_endings_choose_h7x7mp_2** [choose; sentence_endings]
  - Prompt: Choose the correctly punctuated sentence.
  - Stem: Choose the best ending for: put the science tray on the table
  - Model: Put the science tray on the table.
- **gen_sentence_endings_choose_gdyejs_3** [choose; sentence_endings]
  - Prompt: Choose the correctly punctuated sentence.
  - Stem: Choose the best ending for: what an exciting final race
  - Model: What an exciting final race!

### gen_sentence_endings_insert
- **gen_sentence_endings_insert_2k0p2e_1** [insert; sentence_endings]
  - Prompt: Add the capital letter and sentence-ending mark.
  - Stem: close the library door quietly
  - Model: Close the library door quietly.
- **gen_sentence_endings_insert_2u0ard_2** [insert; sentence_endings]
  - Prompt: Add the capital letter and sentence-ending mark.
  - Stem: what a peaceful garden
  - Model: What a peaceful garden!
- **gen_sentence_endings_insert_201hog_3** [insert; sentence_endings]
  - Prompt: Add the capital letter and sentence-ending mark.
  - Stem: where did the water bottle go
  - Model: Where did the water bottle go?

### gen_speech_insert
- **gen_speech_insert_1329w0m_1** [insert; speech]
  - Prompt: Add the direct-speech punctuation.
  - Stem: Ava asked, can we start now?
  - Model: Ava asked, "Can we start now?"
- **gen_speech_insert_13c9hpl_2** [insert; speech]
  - Prompt: Add the direct-speech punctuation.
  - Stem: Ben asked, where is the spare torch?
  - Model: Ben asked, "Where is the spare torch?"
- **gen_speech_insert_12iaomo_3** [insert; speech]
  - Prompt: Add the direct-speech punctuation.
  - Stem: Maya said, please close the gate.
  - Model: Maya said, "Please close the gate."

## Fixed P12 choice samples by skill

### apostrophe_contractions
- **fx12_apostrophe_contractions_001**: Choose the sentence with contractions punctuated correctly.
  - Correct: I can't find the library card.
- **fx12_apostrophe_contractions_002**: Choose the sentence with contractions punctuated correctly.
  - Correct: We didn't hear the final whistle.
- **fx12_apostrophe_contractions_003**: Choose the sentence with contractions punctuated correctly.
  - Correct: They're waiting beside the coach.
- **fx12_apostrophe_contractions_004**: Choose the sentence with contractions punctuated correctly.
  - Correct: You'll need a sharper pencil.

### apostrophe_possession
- **fx12_apostrophe_possession_001**: Choose the correct possessive apostrophe.
  - Correct: The teachers' notices were on the desk.
- **fx12_apostrophe_possession_002**: Choose the correct possessive apostrophe.
  - Correct: The children's bags were on the bench.
- **fx12_apostrophe_possession_003**: Choose the correct possessive apostrophe.
  - Correct: The girls' jackets were on the hook.
- **fx12_apostrophe_possession_004**: Choose the correct possessive apostrophe.
  - Correct: The boys' coats were on the rail.

### bullet_points
- **fx12_bullet_points_001**: Choose the bullet list with a clear stem and consistent bullets.
  - Correct: Library checklist:
- check the lantern
- pack the telescope
- label the clipboard
- **fx12_bullet_points_002**: Choose the bullet list with a clear stem and consistent bullets.
  - Correct: Science lab checklist:
- check the notebook
- pack the poster
- label the seed tray
- **fx12_bullet_points_003**: Choose the bullet list with a clear stem and consistent bullets.
  - Correct: Sports hall checklist:
- check the map
- pack the sketchbook
- label the model bridge
- **fx12_bullet_points_004**: Choose the bullet list with a clear stem and consistent bullets.
  - Correct: Music room checklist:
- check the camera
- pack the compass
- label the football

### colon_list
- **fx12_colon_list_001**: Choose the sentence that uses a colon correctly before the list.
  - Correct: The library needed three things: maps, torches and camera.
- **fx12_colon_list_002**: Choose the sentence that uses a colon correctly before the list.
  - Correct: The science lab needed three things: brushes, chalks and aprons.
- **fx12_colon_list_003**: Choose the sentence that uses a colon correctly before the list.
  - Correct: The sports hall needed three things: ropes, helmets and gloves.
- **fx12_colon_list_004**: Choose the sentence that uses a colon correctly before the list.
  - Correct: The music room needed three things: scripts, costumes and props.

### comma_clarity
- **fx12_comma_clarity_001**: Choose the comma placement that makes the sentence clear.
  - Correct: Most of the time, the children waited patiently.
- **fx12_comma_clarity_002**: Choose the comma placement that makes the sentence clear.
  - Correct: After supper, the helpers washed their hands.
- **fx12_comma_clarity_003**: Choose the comma placement that makes the sentence clear.
  - Correct: Before cooking, the visitors packed their bags.
- **fx12_comma_clarity_004**: Choose the comma placement that makes the sentence clear.
  - Correct: When the rain stopped, the players checked the map.

### dash_clause
- **fx12_dash_clause_001**: Choose the sentence that uses a dash correctly between related clauses.
  - Correct: The lantern vanished – the swimming pool was still busy.
- **fx12_dash_clause_002**: Choose the sentence that uses a dash correctly between related clauses.
  - Correct: The notebook arrived – the workshop was still busy.
- **fx12_dash_clause_003**: Choose the sentence that uses a dash correctly between related clauses.
  - Correct: The map fell – the school office was still busy.
- **fx12_dash_clause_004**: Choose the sentence that uses a dash correctly between related clauses.
  - Correct: The camera opened – the wildlife centre was still busy.

### fronted_adverbial
- **fx12_fronted_adverbial_001**: Choose the sentence with the comma after the fronted adverbial.
  - Correct: Before sunrise, the lantern sparkled.
- **fx12_fronted_adverbial_002**: Choose the sentence with the comma after the fronted adverbial.
  - Correct: After the rehearsal, the notebook jammed.
- **fx12_fronted_adverbial_003**: Choose the sentence with the comma after the fronted adverbial.
  - Correct: Without warning, the map rattled.
- **fx12_fronted_adverbial_004**: Choose the sentence with the comma after the fronted adverbial.
  - Correct: During the storm, the camera floated.

### hyphen
- **fx12_hyphen_001**: Choose the sentence where the hyphen avoids ambiguity.
  - Correct: The well-known author made the meaning clear.
- **fx12_hyphen_002**: Choose the sentence where the hyphen avoids ambiguity.
  - Correct: The fast-moving shark made the meaning clear.
- **fx12_hyphen_003**: Choose the sentence where the hyphen avoids ambiguity.
  - Correct: The little-used room made the meaning clear.
- **fx12_hyphen_004**: Choose the sentence where the hyphen avoids ambiguity.
  - Correct: The man-eating job made the meaning clear.

### list_commas
- **fx12_list_commas_001**: Choose the sentence with commas used correctly in the list.
  - Correct: The library had maps, torches and camera.
- **fx12_list_commas_002**: Choose the sentence with commas used correctly in the list.
  - Correct: The science lab had brushes, chalks and aprons.
- **fx12_list_commas_003**: Choose the sentence with commas used correctly in the list.
  - Correct: The sports hall had ropes, helmets and gloves.
- **fx12_list_commas_004**: Choose the sentence with commas used correctly in the list.
  - Correct: The music room had scripts, costumes and props.

### parenthesis
- **fx12_parenthesis_001**: Choose the sentence with the parenthesis marked correctly.
  - Correct: The museum, which opened last year, welcomed the class.
- **fx12_parenthesis_002**: Choose the sentence with the parenthesis marked correctly.
  - Correct: The library, our favourite place, was full of visitors.
- **fx12_parenthesis_003**: Choose the sentence with the parenthesis marked correctly.
  - Correct: The robot, a careful design, won first prize.
- **fx12_parenthesis_004**: Choose the sentence with the parenthesis marked correctly.
  - Correct: The captain, who led the rescue, smiled at the team.

### semicolon
- **fx12_semicolon_001**: Choose the sentence that joins two related clauses with a semi-colon.
  - Correct: The lantern vanished; the swimming pool was still busy.
- **fx12_semicolon_002**: Choose the sentence that joins two related clauses with a semi-colon.
  - Correct: The notebook arrived; the workshop was still busy.
- **fx12_semicolon_003**: Choose the sentence that joins two related clauses with a semi-colon.
  - Correct: The map fell; the school office was still busy.
- **fx12_semicolon_004**: Choose the sentence that joins two related clauses with a semi-colon.
  - Correct: The camera opened; the wildlife centre was still busy.

### semicolon_list
- **fx12_semicolon_list_001**: Choose the complex list punctuated with semi-colons.
  - Correct: We visited York, England; Cardiff, Wales; and Belfast, Northern Ireland.
- **fx12_semicolon_list_002**: Choose the complex list punctuated with semi-colons.
  - Correct: The helpers were Paris, France; Rome, Italy; and Madrid, Spain.
- **fx12_semicolon_list_003**: Choose the complex list punctuated with semi-colons.
  - Correct: The picnic included Dundee, Scotland; Bangor, Wales; and Derry, Northern Ireland.
- **fx12_semicolon_list_004**: Choose the complex list punctuated with semi-colons.
  - Correct: The display listed Oxford, England; Galway, Ireland; and Perth, Scotland.

### sentence_endings
- **fx12_sentence_endings_001**: Choose the correctly punctuated question.
  - Correct: Where did the lantern land near the library?
- **fx12_sentence_endings_002**: Choose the correctly punctuated question.
  - Correct: Why was the forest path closed after lunch?
- **fx12_sentence_endings_003**: Choose the correctly punctuated question.
  - Correct: When should the map be returned?
- **fx12_sentence_endings_004**: Choose the correctly punctuated question.
  - Correct: How did the camera get inside the book corner?

### speech
- **fx12_speech_001**: Choose the correctly punctuated direct speech.
  - Correct: Ava asked, "Can we start the experiment?"
- **fx12_speech_002**: Choose the correctly punctuated direct speech.
  - Correct: Ben asked, "Where is the spare torch?"
- **fx12_speech_003**: Choose the correctly punctuated direct speech.
  - Correct: Maya said, "Please close the gate."
- **fx12_speech_004**: Choose the correctly punctuated direct speech.
  - Correct: Noah shouted, "What a brilliant save!"

