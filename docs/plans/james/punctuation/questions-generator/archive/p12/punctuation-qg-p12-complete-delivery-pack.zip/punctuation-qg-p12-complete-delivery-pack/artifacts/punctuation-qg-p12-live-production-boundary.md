# Punctuation QG P12 — Live Production Boundary

## What is live/merged now

GitHub PR #822 is a merged P11 evidence hardening PR. Its checked-in production smoke reports:

- release id: `punctuation-qg-p11-2026-05-01`
- production runtime items: 1,268
- fixed items: 148
- generated items: 1,120
- generated depth: 40
- production origin: `https://ks2.eugnel.uk`

The same smoke artefact explicitly leaves `workerCommitSha` as `null`, so it does not prove deployed Worker commit identity. It also leaves Admin Hub production coverage unclaimed.

## What this P12 pack proves

This P12 pack is a local source expansion prepared against the uploaded lean ZIP snapshot `ks2-mastery-lean-05012344.zip`. It proves, by local audit/test, that the patched source can produce:

- fixed items: 512
- generated items: 2,800
- total runtime items: 3,312
- generated families: 28
- templates per generated family: 100

## What is not yet proven

This P12 pack does **not** prove the 3,312-item pool is live in production. To claim that, deploy this patch and capture a new live smoke artefact with:

- production origin
- timestamp
- release id `punctuation-qg-p12-3000-2026-05-02`
- runtime item count 3,312
- generated depth 100
- generated command-path item proof
- Smart session proof
- Parent Hub evidence
- worker/deployment identity where available

Correct current claim: **P11 1,268-item pool has GitHub production-smoke evidence; P12 3,312-item pool is a locally verified expansion pack awaiting apply/deploy/smoke.**
