# Punctuation QG P12 — 3000+ Question Pool Expansion, Quality and Release Contract

## Evidence boundary

This pack is built against the uploaded lean ZIP snapshot `ks2-mastery-lean-05012344.zip` and the merged GitHub PR #822 evidence for P11. The uploaded ZIP proves the supplied source snapshot; GitHub proves the fetched repository ref; local Node runs prove behaviour for the extracted source in this environment; live production is only proven by a production smoke artefact with origin, release id, timestamp and pass/fail result.

P11 is production-smoke evidenced. The live smoke artefact reports `origin: https://ks2.eugnel.uk`, `environment: production`, `releaseId: punctuation-qg-p11-2026-05-01`, `runtimeItemCount: 1268`, `generatedDepth: 40`, and `timestamp: 2026-05-01T22:20:29.625Z`. Its known caveat remains that `workerCommitSha` is `null`, so it does not prove deployed Worker commit identity.

P12 is not live-production evidenced by this pack. P12 is a source expansion/add-on that must be applied, merged, deployed and smoke-tested before anyone may claim the 3,312-item pool is live.

## Product aim

The product issue was not just “marking correctness”. The learner-facing issue was that short sessions and a small denominator made the experience feel repetitive, too quick to finish, and too easy to exhaust. P12 therefore targets a much larger pool and a broader first-click surface while keeping marking, answer surfaces and session rotation verifiable.

P12 target:

- at least 500 fixed questions;
- at least 2,500 generated questions;
- at least 3,000 total runtime questions;
- generated family depth raised to 100;
- all generated families have 100 templates;
- generated stems are unique across the production generated runtime;
- model/correct answers mark correctly;
- Smart/Guided sessions retain visible mode variety and no immediate repeated items.

## Delivered source changes in this add-on

The add-on patch introduces or updates:

- `shared/punctuation/fixed-expansion-items-p12.js` — 364 additional fixed choice items across the published punctuation skills.
- `shared/punctuation/manual-deep-expansion-bank.js` — deep manual generated-template expansion for all 28 generator families.
- `shared/punctuation/content.js` — includes the P12 fixed expansion bank.
- `shared/punctuation/manual-expansion-bank.js` — composes P11 and P12 manual generated-template banks.
- `shared/punctuation/generators.js` — raises `PRODUCTION_DEPTH` to 100 through the manual expansion target.
- `src/subjects/punctuation/service-contract.js` — updates the release id to `punctuation-qg-p12-3000-2026-05-02`, generated seed to `punctuation-r5-depth100-3000-plus`, and keeps the default round length at six questions rather than returning to four.
- `scripts/audit-punctuation-qg-p12-expansion.mjs` — source-level product audit for count, uniqueness, marking and session properties.
- `tests/punctuation-qg-p12-expansion.test.js` — regression suite for the 3000+ source pool.

## Verified local P12 result

Local Node version: Node v22.16.0.

The final audit result is `PASS` with:

- fixed items: 512;
- P12 fixed additions: 364;
- generated items: 2,800;
- total runtime items: 3,312;
- generated families: 28;
- templates per family: 100 minimum and 100 maximum;
- unique generated stems: 2,800;
- generated stem duplicate count: 0;
- generated model duplicate count: 64;
- model failure count: 0;
- session simulation: 24 sessions, 240 surfaced items, minimum 3 modes per session, no immediate repeats.

The node test suite for the P12 expansion passed six subtests:

1. exposes a 3000+ runtime pool;
2. keeps one hundred unique templates in every generated family;
3. model answers and fixed-choice answers mark correctly;
4. adds at least 350 new fixed choice items across all published skills;
5. Smart sessions surface varied items without immediate repeats;
6. runtime items have complete learner answer surfaces.

## Known honest limits

This pack does not by itself prove live production deployment of P12. The latest inspected production smoke evidence still proves P11 with 1,268 runtime items, not P12 with 3,312 runtime items.

`workerCommitSha` remains a known limitation in the P11 live smoke evidence. P12 acceptance should require worker/deployment identity if the platform can expose it.

The generated model duplicate count is 64. The audit accepts this because some sibling mode families intentionally share the same final corrected sentence while asking through a different mode. The stricter learner-facing uniqueness condition, generated stem uniqueness, is 2,800/2,800.

This pack does not claim adult/human review of all 3,312 displayed items. It creates a larger source pool and quality gate. A regenerated reviewer/surface pack is still required before a full human-content certification claim.

## Required release gates before production claim

Before claiming P12 live production:

1. Apply the add-on patch cleanly to `main`.
2. Run `npm run verify:punctuation-qg:p12-expansion` on Node 22.
3. Run the existing affected punctuation service/session tests.
4. Regenerate reviewer/surface evidence for the 3,312-item pool.
5. Run a production smoke after deployment and require:
   - production origin;
   - release id `punctuation-qg-p12-3000-2026-05-02`;
   - runtime item count 3,312;
   - generated depth 100;
   - generated command-path item evidence;
   - Smart round evidence with more than a one-item smoke if practical;
   - Parent Hub evidence;
   - worker or deployment identity if available;
   - timestamp and pass/fail result.

Correct source claim after this pack passes locally:

> Punctuation QG P12 source expansion is locally verified for a 3,312-item runtime pool.

Correct production claim only after deployment smoke:

> Punctuation QG P12 is live in production and serving the 3,312-item pool.

Do not claim the second sentence from this pack alone.
