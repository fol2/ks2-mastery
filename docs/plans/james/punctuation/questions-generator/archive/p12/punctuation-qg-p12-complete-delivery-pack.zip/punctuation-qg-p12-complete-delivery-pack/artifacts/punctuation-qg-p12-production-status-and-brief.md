# Punctuation QG P12 — Production Status and Cantonese Brief

## Production status

P11 is live-production evidenced. PR #822 was merged, and the checked production smoke evidence records a production origin, release id `punctuation-qg-p11-2026-05-01`, runtime item count 1,268, and generated depth 40. This means the P11 pool is evidenced as live.

P12 is not live-production evidenced yet. The P12 expansion pack prepared here raises the source/runtime pool to 3,312 items locally, but it has not been merged/deployed/smoked as live production evidence in the artefacts I inspected.

## What this pack gives you

This pack gives a concrete source expansion, not just a plan:

- 512 fixed runtime items;
- 364 new P12 fixed additions;
- 2,800 generated runtime items;
- 3,312 total runtime items;
- 28 generated families;
- 100 templates per generated family;
- 2,800 unique generated stems;
- zero model marking failures;
- source-level session audit with no immediate repeats.

## Cantonese brief

而家可以好清楚咁分兩層：P11 係有 live production smoke 證據，production 上見到 1,268 題；但 P12 呢個 3,312 題 expansion 仍然係 source/add-on pack，未係 live production。

今次 P12 唔係再寫 contract 等人做，而係直接畀你一個可以 apply 嘅 expansion patch。目標係由 1,268 題升到 3,312 題，fixed 去到 512，generated 去到 2,800。呢個已經超過你講嘅 500 fixed + 2,500 generated 目標。

最重要嘅 product 改善係：唔再只靠細 pool 反覆出相似題。P12 令每個 generated family 去到 100 templates，亦加咗大量 fixed choice 題，令 first-click selection 同 Smart session 都有更大分母。Local audit 顯示 generated stems 2,800 個全部 unique，model answer marking failure 係 0。

但我唔會呃你：呢個 pack 未證明 live site 已經 serving 3,312 題。要 production claim，下一步一定要 apply、merge、deploy，然後跑新 production smoke，睇到 release id 變成 `punctuation-qg-p12-3000-2026-05-02`，runtime item count 變成 3,312，先可以講 P12 live。
