# Punctuation QG P12 — Quality Summary

## Delivered expansion

P12 raises the Punctuation QG runtime pool to 3,312 items:

- 512 fixed items, including 364 new hand-authored fixed choice items.
- 2,800 generated items from 28 generated families.
- 100 templates per generated family.
- 2,800 unique generated stems.
- 2,736 unique generated models; 64 model duplicates remain across families/modes where the same teaching sentence is intentionally surfaced through a different answer mode.

## UX/session checks

The P12 tests include a Smart-session surface check. The sampled sessions showed:

- no immediate item repeats;
- at least 3 modes visible per sampled session;
- 141 unique surfaced items across 24 sampled sessions / 240 surfaced questions.

A stale UI copy issue was also fixed: the skill detail modal no longer hard-codes focused practice as “four questions”, because the current default is six and round lengths are configurable.

## Marking checks

The audit and tests validate that:

- every generated model answer marks correctly;
- every new fixed choice answer marks correctly;
- learner answer surfaces exist for choice, insert, fix, combine, paragraph, and transfer modes;
- the mixed apostrophe paragraph checker avoids false rejection of correct contractions while still rejecting unrepaired possessive phrases.

## Caveat

This is a source-content expansion and local verification pack. It is not yet live production proof until deployed and smoke-tested against the production origin.
