---
title: "Punctuation QG P20 Systematic Expansion Completion Report"
phase: "P20"
subject: "punctuation"
status: "source-and-local-verification-complete"
releaseId: "punctuation-qg-p20-15072-2026-05-04"
generatedAt: "2026-05-05T00:04:41Z"
---

# Punctuation QG P20 Systematic Expansion Completion Report

This report records the source/local implementation of P15-P20 systematic question-pool expansion for punctuation. It is intentionally limited to source and local verification. It does not certify live production until `reports/punctuation/punctuation-qg-p20-production-smoke.json` is produced from the deployed environment and `npm run verify:punctuation-qg:p20-live` passes.

## Implementation summary

P20 expands the punctuation runtime from the P14 3,564-item pool to a 15,072-item runtime pool.

Runtime composition:

- 512 fixed items.
- 28 legacy baseline generator families capped by their existing 100-template banks.
- 14 legacy transfer families expanded to 120 templates each.
- 84 new P20 systematic generator families: six new families for each of the 14 published punctuation skills.
- Production depth raised to 120.
- Release ID: `punctuation-qg-p20-15072-2026-05-04`.

The new systematic source is `shared/punctuation/p20-systematic-expansion-bank.js`. It generates deterministic KS2-safe template banks for choose, insert, fix, combine, paragraph, and transfer modes. The generator now caps each family by the actual template-bank length, so legacy 100-template families are not over-cycled when P20 production depth is 120.

## Acceptance metrics

The P20 expansion audit passes with these headline counts:

| Metric | Value |
|---|---:|
| Runtime items | 15,072 |
| Generated items | 14,560 |
| Fixed items | 512 |
| Generator families | 126 |
| Published punctuation skills | 14 |
| Unique learner-facing surfaces | 15,066 |
| Unique variant signatures | 15,072 |
| Generated duplicate surface groups | 0 |
| Legacy fixed duplicate surface groups, reported only | 6 |
| Model self-marking failures | 0 |

Mode balance:

| Mode | Runtime items |
|---|---:|
| choose | 2,420 |
| insert | 2,400 |
| fix | 2,397 |
| combine | 2,286 |
| paragraph | 2,185 |
| transfer | 3,384 |

## Added gates and evidence

The patch adds these scripts:

- `scripts/audit-punctuation-qg-p20-expansion.mjs`
- `scripts/build-punctuation-qg-p20-evidence.mjs`
- `scripts/simulate-punctuation-qg-p20-heavy-play.mjs`
- `scripts/validate-punctuation-qg-p20-live-evidence.mjs`
- `scripts/validate-punctuation-qg-p20-expansion-report.mjs`

The patch adds these npm commands:

- `npm run build:punctuation-qg:p20-evidence`
- `npm run simulate:punctuation-qg:p20-heavy-play`
- `npm run audit:punctuation-qg:p20-expansion`
- `npm run validate:punctuation-qg:p20-expansion-report`
- `npm run verify:punctuation-qg:p20-expansion`
- `npm run verify:punctuation-qg:p20-live`
- `npm run verify:punctuation-qg:p20`

The source/local expansion verifier runs the evidence builder, heavy-play simulation, audit, and a machine validator over the generated P20 audit report. The node tests remain in the patch as post-P20 test coverage and can be run separately.

The live verifier is expected to fail until production smoke evidence is added after deployment. That is deliberate. The patch does not fake production.

## Local verification run

Verified from the patched lean snapshot with Node 22.16.0:

```bash
npm run verify:punctuation-qg:p20-expansion
node --test tests/punctuation-qg-p20-expansion.test.js
node --test tests/punctuation-manual-expansion.test.js \
  tests/punctuation-qg-p12-expansion.test.js \
  tests/punctuation-canonical-depth-source.test.js \
  tests/punctuation-capacity-raise.test.js \
  tests/punctuation-closed-lexical-preservation-p10.test.js \
  tests/punctuation-p14-transfer-coverage.test.js \
  tests/punctuation-qg-p20-expansion.test.js
```

The verifier and the listed node-test checks passed locally. The P20 live verifier remains deployment-evidence-gated.

## Remaining deployment acceptance

After deployment, produce a real `reports/punctuation/punctuation-qg-p20-production-smoke.json` with:

- environment/origin,
- timestamp,
- release ID,
- runtime item count,
- authenticated learner coverage,
- admin/debug coverage,
- no failed smoke checks.

Then run:

```bash
npm run verify:punctuation-qg:p20-live
npm run verify:punctuation-qg:p20
```

P20 is not production-certified until those live checks pass.
